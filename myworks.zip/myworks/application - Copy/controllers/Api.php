<?php
//defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . "/libraries/REST_Controller.php";

class Api extends REST_Controller {

	public function __construct()
	{
		if (isset($_SERVER['HTTP_ORIGIN'])) {
           header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
           header('Access-Control-Allow-Credentials: true');
           header('Access-Control-Max-Age: 86400');    // cache for 1 day
       }

       // Access-Control headers are received during OPTIONS requests
       if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

           if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
               header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

           if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
               header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

           exit(0);
       }
       parent::__construct();
		$this->load->database();
	}

	public function index_get()
	{

		$this->response('kljnbikjhnok');
	}

	
	public function get_admin_credentials_post(){
		//$this->post('bodyString');
		  
		
		//$admindata =$this->db->get('admin');
		if($this->post('username')=="admin"){
		$this->db->where('username',$this->post('username'));
		$this->db->where('password',$this->post('password'));
		$admindata= $this->db->get('admin')->row();
		if($admindata)
			{
				return $this->response($admindata,200);
		   }
		  else {
		      return $this->response('failure',400);
		}
	 }
	 else if($this->post('username')!="admin"){
	 	$this->db->where('username',$this->post('username'));
	 	$this->db->where('password',$this->post('password'));
		$emp_login= $this->db->get('emp')->row();
	 	if($emp_login)
			{
				return $this->response($emp_login,200);
		   }
		  else {
		      return $this->response('failure',400);
		}
	 }
	 else {
	 	return $this->response('Invalid Login',400);
	 }
}


		// $username = $this->post('username');
		// echo $username;
		//   $admindata = $this->db->query('select username,password from `admin` where username="'.$username.'" ')->row();
		//    if($admindata){$this->response($admindata,200);
		//    }{
		//       $this->response('failure',400);
		// }//$empdata = $this->db->query('select username,password from emp where username=$this->post('username') and password=$this->post('password')')->row();
		// if(($this->post('username'))=='admin'){
		// //	$this->db->where('username',$this->post('username'));
		// //  $this->db->where('password',$this->post('password'));
		//     $admindata= $this->db->get('admin')->row();
		//     $this->response($admindata,200);
		// }
		// else if(($this->post('username'))!='admin'){
		//  $this->db->where('username',$this->post('username'));
		//  $this->db->where('password',$this->post('password'));
		//  $emp_login = $this->db->get('emp')->row();
		//  $this->response($emp_login,200);
		// }
		// $this->db->where('username',$this->post('username'));
		// $this->db->where('password',$this->post('password'));
		// $admindata= $this->db->get('admin')->row();
		// $emp_login = $this->db->get('emp')->row();
		//  if($admindata){
		// 	$this->response($admindata,200);
		// }else if($empdata){
		// 	$this->response($empdata,200);
		// }
		// else 
		// {
		// 	$this->response('failure',400);
		// }
	


	 
	public function projectInsert_post(){

		$data['emp_id']=$this->post('emp_name');
		$data['project_title']=$this->post('project_title');
		$data['developed_for']=$this->post('developed_for');
		$data['project_desc']=$this->post('project_desc');
		$data['project_dur']=$this->post('project_dur');
		$data['project_type']=$this->post('project_type');

		$data['front_end']=$this->post('front_end');
		$data['back_end']=$this->post('back_end');

		$this->db->insert('project',$data);
		$id=$this->db->insert_id();
		
		if($id){
			 return $this->response('Data Inserted',200);
		}else {
			return $this->response('Not Inserted',400); 
		}
	}

	public function projectUpdate_post(){

		//$data['emp_id']=$this->post('emp_name');
		$data['project_title']=$this->post('project_title');
		$data['developed_for']=$this->post('developed_for');
		$data['project_desc']=$this->post('project_desc');
		$data['project_dur']=$this->post('project_dur');
		$data['project_type']=$this->post('project_type');

		$data['front_end']=$this->post('front_end');
		$data['back_end']=$this->post('back_end');

		$this->db->where('id',$this->post('id'));
		$id=$this->db->update('project',$data);  
		
		if($id){
			 return $this->response('Data Update',200);
		}else {
			return $this->response('Not Update',400); 
		}
	}




	public function retriveProject_get(){
		 
		$result = $this->db->get('project')->result();
		$this->response($result,200);
	 
	}


	public function deleteProject_post(){
				//$this->db->set('status',0)
				 $this->db->where('id',$this->post('id'));
				$delete =	$this->db->delete('project');
  			if($delete){
  				return $this->response('deleted',200);
  			}
  			else {
  				return $this->response('not deleted',400);
  			}
	}


	public function addEmployee_post(){

		 
		 $data['emp_id']=$this->post('emp_id');
		 $data['emp_name']=$this->post('emp_name');
		$data['contact_personal']=$this->post('contact_personal');
		$data['contact_college']=$this->post('contact_college');

		$data['email']=$this->post('email');
		$data['org_email']=$this->post('org_email');
		$data['pf_no']=$this->post('pf_no');
		$data['passport']=$this->post('passport');
		$data['pan']=$this->post('pan');
		$data['aadhar']=$this->post('aadhar');
		 
		// $name= $_FILES["file"]["name"];
		// $type= $_FILES["file"]["type"];
		// 	$ftpe = pathinfo($_FILES["file"]["name"],PATHINFO_EXTENSION);

		// 	move_uploaded_file($_FILES["file"]["tmp_name"], "./uploads".$name);
		// // $this->insert_docs($file_name);
	$data['photo']= $this->post('photo');

		$this->db->insert('employees',$data);
		$id= $this->db->insert_id();

		if($id){
			 return $this->response('Data Inserted',200);
		}else {
			return $this->response('Not Inserted',400); 
		}
	}

	public function insert_docs_post( ){
		 
		$name= $_FILES["uploadFile"]["name"];
		$type= $_FILES["uploadFile"]["type"];
			$ftpe = pathinfo($_FILES["uploadFile"]["name"],PATHINFO_EXTENSION);

			move_uploaded_file($_FILES["uploadFile"]["tmp_name"], "uploads".$name);
		$data['file_name']=$name;
		$data['file_type']=	$type;
		$this->db->insert('docs',$data);		

		return $this->response($file_name,200); 
	}



	public function updateEmployee_post(){

		$data['emp_id']=$this->post('emp_id');
		$data['emp_name']=$this->post('emp_name');
		$data['contact_personal']=$this->post('contact_personal');
		$data['contact_college']=$this->post('contact_college');

		$data['email']=$this->post('email');
		$data['org_email']=$this->post('org_email');
		$data['pf_no']=$this->post('pf_no');
		$data['passport']=$this->post('passport');
		$data['pan']=$this->post('pan');
		$data['aadhar']=$this->post('aadhar');

		$this->db->where('id',$this->post('id'));
		$id = $this->db->update('employees',$data);
		

		if($id){
			 return $this->response('Data Inserted',200);
		}else {
			return $this->response('Not Inserted',400); 
		}
	}
	public function getEmployees_get(){

				  
					 $this->db->order_by('id', 'DESC');	
		$employees = $this->db->get('employees')->result();
		$this->response($employees,200);
	}


	public function deleteEmployee_post(){

		$this->db->where('id',$this->post('id'));
	$delete=$this->db->delete(employees);
	if($delete){

		return $this->response('deleted',200);
	}else{
		return $this->response('not deleted',400);
	}
	}


	public function  upload_files_post(){

	 
 
 
  $originalName = $_FILES['file']['name'];
  $ext = '.'.pathinfo($originalName, PATHINFO_EXTENSION);
  $generatedName = 'ji'.$ext;
  $filePath = $generatedName;
 
 
 
  if (move_uploaded_file($_FILES['file']['tmp_name'], "uploads".$filePath)) {
    echo json_encode(array(
      'status'        => true,
      'originalName'  => $originalName,
      'generatedName' => $generatedName
    ));
  }
 

  
	}

public function add_experience_post(){
$temp = $this->post('experience');
$temp['skill'];
   $this->response();
  //      $data =array();
  // foreach($this->post('organization') as $index => $val){
    
  //     $data[]=$val;
  //  }
    /*
   	$data['organization']=$this->post('organization');
   	$data['profession']=$this->post('profession');
	$data['role']=$this->post('role');
   	$data['from']=$this->post('from');
   	$data['to']=$this->post('to');
   	$data['emp_name']=$this->post('emp_name');
   $data['emp_id']=$this->post('emp_id');
   
  //  $data=trim($data);
  //   echo $data;
		// $data['organization']=$this->post('organization');
		// $data['profession']=$this->post('profession');
		// $data['from']=$this->post('from');
		// $data['to']=$this->post('to');
		// $data['role']=$this->post('role');
 
		$this->db->insert('emp_experience',$data);
		$id= $this->db->insert_id();
		if($id){
		return $this->response('success',200);
		}
		else {
		return $this->response('failure',400);
		}
		*/
}


public function Register_employee_post(){
		$total=$this->db->get('emp')->result();
		$total_emp= count($total);


		if($total_emp==0){
		 $data['emp_id']="AKV-IT"."-1";
		} else {
			 $data['emp_id']="AKV-IT-".++$total_emp;
		}

		$data['emp_name']=$this->post('emp_name');
		$data['username']=$this->post('username');
		$data['password']=$this->post('password');
		$data['type']='employee';
		  
		$this->db->insert('emp',$data);
		$id= $this->db->insert_id();
		if($id){
			 return $this->response('Data Inserted',200);
		}else {
			return $this->response('Not Inserted',400); 
		}
}

public function get_registered_employee_post(){ 
			$this->db->where('id',$this->post('id'));
	$employee=$this->db->get('emp')->row();
	if($employee){
			 return $this->response($employee ,200);
		}else {
			return $this->response('Not Found',400); 
		}
}	

public function get_emp_commu_data_post(){ 
			$this->db->where('emp_id',$this->post('id'));
	$employee=$this->db->get('employees')->row();
	if($employee){
			 return $this->response($employee ,200);
		}else {
			return $this->response('Not Found',400); 
		}
}	 


public function totalLeaves_post(){
			$this->db->where('emp_id',$this->post('emp_id'));
	$tl=$this->db->get('leaves')->row();
	if($tl){
			 return $this->response($tl ,200);
	}else {
			 return $this->response('No data Found',400);
	}
}

public function addSickLeaves_post(){
	$this->db->where('emp_id',$this->post('emp_id'));
$sl=$this->db->get('leaves')->row()->sl;

$from = strtotime($this->post('from')); // or your date as well
$to = strtotime($this->post('to'));
$datediff = $to - $from;
$diff= $datediff +(60 * 60 * 24);
$days=floor($diff / (60 * 60 * 24));

 if(($sl) < ($days)){
 	return $this->response('Selected Leaves Morethan the Available Leaves',400); 
 }
 else{
 		$data['emp_id']=$this->post('emp_id');
 		$data['emp_name']=$this->post('emp_name');
		$data['from']=$this->post('from');
		$data['to']=$this->post('to');
		$data['leave_type']='sl';
		$data['reason']= $this->post('reason');
		$data['no_of_leaves']= $days;
		$this->db->insert('emp_leaves',$data);
		$id= $this->db->insert_id();
		
		if($id){
			$this->db->set('sl',($sl-$days));
			$this->db->where('emp_id',$this->post('emp_id'));
		 $this->db->update('leaves'); 
		 $this->session->set_flashdata('msg', 'Category added');
			return $this->response('inserted and updated',200);
		} 
   
 }
}

public function updateSickLeaves_post(){
	$this->db->where('emp_id',$this->post('emp_id'));
$sl=$this->db->get('leaves')->row()->sl;

$from = strtotime($this->post('from')); // or your date as well
$to = strtotime($this->post('to'));
$datediff = $to - $from;
$diff= $datediff +(60 * 60 * 24);
$days=floor($diff / (60 * 60 * 24));

$this->db->where('id',$this->post('id'));
$exist_days=$this->db->get('emp_leaves')->row();
$exist_daysdiff = strtotime($exist_days->to) - strtotime($exist_days->from);
$exist_diff= $exist_daysdiff +(60 * 60 * 24);
$exist_day=floor($exist_diff / (60 * 60 * 24));

 if(($sl) < ($days)){
 	return $this->response('Selected Leaves Morethan the Available Leaves',400); 
 }
 else if(($exist_day==$days))
 {
 		$data['emp_id']=$this->post('emp_id');
 		$data['emp_name']=$this->post('emp_name');
		$data['from']=$this->post('from');
		$data['to']=$this->post('to');
		$data['leave_type']='sl';
		$data['reason']= $this->post('reason');
		$data['no_of_leaves']= $days;

		$this->db->where('id',$this->post('id'));
		$id=$this->db->update('emp_leaves',$data);
		if($id){
			 return $this->response('updated',200);
		}

 }
 else if(($exist_day > $days)){
 	$data['emp_id']=$this->post('emp_id');
 		$data['emp_name']=$this->post('emp_name');
		$data['from']=$this->post('from');
		$data['to']=$this->post('to');
		$data['leave_type']='sl';
		$data['reason']= $this->post('reason');
		$data['no_of_leaves']= $days;

		$this->db->where('id',$this->post('id'));
		$id=$this->db->update('emp_leaves',$data);
	 		
		if($id){
		 $this->db->set('sl',($sl+$days));
		 $this->db->where('emp_id',$this->post('emp_id'));
		 $this->db->update('leaves'); 
		 $this->session->set_flashdata('msg', 'Category added');
		 return $this->response('inserted and updated',200);
 }
}
 else{
 		$data['emp_id']=$this->post('emp_id');
 		$data['emp_name']=$this->post('emp_name');
		$data['from']=$this->post('from');
		$data['to']=$this->post('to');
		$data['leave_type']='sl';
		$data['reason']= $this->post('reason');
		$data['no_of_leaves']= $days;

		$this->db->where('id',$this->post('id'));
		$id=$this->db->update('emp_leaves',$data);
	 		
		if($id){
		 $this->db->set('sl',($sl-$days));
		 $this->db->where('emp_id',$this->post('emp_id'));
		 $this->db->update('leaves'); 
		 $this->session->set_flashdata('msg', 'Category added');
		 return $this->response('inserted and updated',200);
		} 
   
 }
}

public function empLeaves_post(){
	$this->db->where('emp_id',$this->post('emp_id'));
$sl=$this->db->get('emp_leaves')->result();
	if($sl){
		return $this->response($sl,200);
	}else{
		return $this->response('not found',400);	
	}
}

}