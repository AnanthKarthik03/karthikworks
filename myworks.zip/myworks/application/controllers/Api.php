<?php
//defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . "/libraries/REST_Controller.php";

class Api extends REST_Controller {

	public function __construct()
	{
		if (isset($_SERVER['HTTP_ORIGIN'])) {
           header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
           header('Access-Control-Allow-Credentials: true');
           header('Access-Control-Max-Age: 86400');    // cache for 1 day
           header("Access-Control-Allow-Origin", "*");
 		header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
       }

      // Access-Control headers are received during OPTIONS requests
       if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

           if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
               header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

           if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
               header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

           exit(0);
       }


       parent::__construct();
		$this->load->database();
		$this->load->model('api_model');


	}

	public function index_get()
	{

		$this->response('test');
	}


	public function addUsers_post(){

		$data['name'] =$this->post('name');
		$data['email'] =$this->post('email');
		$data['username'] =$this->post('username');
		$data['password'] = md5($this->post('password'));
 		$this->db->insert('users',$data);
 		$id=$this->db->insert_id();

		if($id)
		{
			return $this->response($id,200);
		}
		else {
		    return $this->response('not inserted',400);
		}

	}

	public function getUsers_post(){
		//$result=$this->db->query('select *from users')->result();
		$role= $this->post('role');
		if($role=='admin' || $role=='lead'){
			$result=$this->db->query('select email,user_id as value,name as label from users where user_id!='.$this->post('user_id').' ORDER BY role ASC')->result();
		} else{
			$result=$this->db->query('select email,user_id as value,name as label from users where user_id!='.$this->post('user_id').' and role!="admin" and role!="user"  ORDER BY role ASC')->result();
		}
		//$result=$this->db->query('select email,user_id as value,name as label from users where user_id!='.$this->post('user_id').'')->result();
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function loginCheck_post(){
		$username=$this->post('username');
		$password=$this->post('password');
		$login=$this->api_model->loginCheck($username,$password);

		if($login){
			return $this->response($login,200);
		}else {
			return $this->response('invalid login',400);
		}
		//$this->db->where('username', $username);
      //  $this->db->where('password', $password);
      //  $data = $this->db->get('users')->row();

	}

	public function addTicket_post(){

		$data['task'] =$this->post('task');
		$data['category'] =$this->post('category');
		$data['taskpriority'] =$this->post('taskpriority');
		$data['task_desc'] =$this->post('task_desc');
		//$dated='Wed May 24 2017';
		// $date = date("Y-m-d H:i:s", $time);
		$data['start_dt'] =$this->post('start_date');

		// $end_date=date("Y-m-d H:i:s", $ts1);
 	    $data['end_dt'] = $this->post('end_date');
 	    $data['actual_st_date'] = '';
 	    $data['actual_end_date'] = '';

		//$data['end_dt'] =substr($this->post('end_dt'), 0, 10);
		$data['hrs'] =$this->post('hrs');
		$data['assigned_by'] =$this->post('user_id');
		$data['assigned_to'] =$this->post('assigned_to');
		$data['type'] =$this->post('type');
		$data['status'] ='assigned';
		$data['alert_status'] ='1';
		$data['comments'] ='';
		$data['created_by']=$this->post('role');

		$tkt_result= $this->api_model->addTicket($data);
			if($tkt_result){
				return $this->response($tkt_result,200);
		}else{
				return $this->response('upadate fails',400);
		}

	}

	public function updateTicket_post(){

		$data['type'] =$this->post('type');
    	$data['task'] =$this->post('task');
		$data['ticket_id'] =$this->post('ticket_id');
		$data['task_desc'] =$this->post('task_desc');
		//11$data['assigned_by'] =$this->post('assigned_id');
		$data['actual_st_date'] = $this->post('actual_st_date');
 	   //  11strtotime($this->post('actual_end_date'));
 	     $date=strtotime($this->post('actual_end_date'));
 	     $date1=date('Y-m-d',$date);
 	    $data['actual_end_date'] =$date1;
		$data['assigned_to'] =$this->post('assigned_to');
		$data['status'] =$this->post('status');
		$data['comments'] =$this->post('comments');
	    $data['rating'] =$this->post('rating');
   	    $data['approve'] =$this->post('approve');
 		$tkt_update= $this->api_model->updateTicket($data);
		if($tkt_update){
				return $this->response($tkt_update,200);
		}else{
				return $this->response('upadate fails',400);
		}

	}
	public function getTickets_post(){
			$id=$this->post('id');
		$result=$this->api_model->getTickets($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function getTicketsByCategory_post(){
			$id=$this->post('id');


		 $result=$this->api_model->getTicketsByCategory($id);
			//$result=$this->db->query('select * from users')->result();
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function insert_daily_work_post()
	{
		//  print_r($this->post('data'));
		//$b1= $this->post('0');
		//echo $b1['data'];
		//echo $b1->data;

		//$b2=$this->post('1');
		//echo $b2['data'];
		//print_r($this->post('activeList'));
	    $b=sizeof($this->post('activeList'));
		$desc=array();
		$desc1=[];
		for($i=0;$i<$b;$i++){
			//echo $this->post($i);
			//$b1->data
			 // echo $b[$i]['data'];
			 $desc1[$i]= $this->post($i);
		}
		//print_r($desc);
		//print_r($desc1);
		// $data= json_decode(print_r($this->post('data'),true));
		// 	print_r($data);
			// $data1= json_decode(print_r($this->post('0'),true));
			// print_r($data1);
 //for($i=0;$i<$b;$i++){
		$data = array(
			'lecture_id' => $this->post('lecture_id'),
			'date_of_start'=>$this->post('date_of_start'),
			'active_list' => $this->post('activeList'),
			//'active_list' =>  $b$i['data'],
		);
 //}
		 $result=$this->api_model->dailyWork($data,$desc1);
		    return $this->response($result,200);

	}

public function insert_daily_work1_post()
	{
		//  print_r($this->post('data'));
		//$b1= $this->post('0');
		//echo $b1['data'];
		//echo $b1->data;

		//$b2=$this->post('1');
		//echo $b2['data'];
		//print_r($this->post('activeList'));
	    $b=sizeof($this->post('activeList'));
		$desc=array();
		$desc1=[];
		for($i=0;$i<$b;$i++){
			//echo $this->post($i);
			//$b1->data
			 // echo $b[$i]['data'];
			 $desc1[$i]= $this->post($i);
		}
		//print_r($desc);
		//print_r($desc1);
		// $data= json_decode(print_r($this->post('data'),true));
		// 	print_r($data);
			// $data1= json_decode(print_r($this->post('0'),true));
			// print_r($data1);
 //for($i=0;$i<$b;$i++){
		$data = array(
			'lecture_id' => $this->post('lecture_id'),
			'date_of_start'=>$this->post('date_of_start'),
			'active_list' => $this->post('activeList'),
			//'active_list' =>  $b$i['data'],
		);
 //}
		 $result=$this->api_model->dailyWork1($data,$desc1);
		    return $this->response($result,200);

	}
    public function get_daily_work_post()
	{
				$reg_no = $this->post('reg_no');
				$date_of_start = $this->post('date_of_start');
				$date_of_end = $this->post('date_of_end');
				$status = $this->post('status');

        $result = $this->api_model->getDailyWork($reg_no,$date_of_start,$date_of_end,$status);
         return $this->response($result,200);
	}

	public function getAllTickets_get(){
			//$id=$this->post('id');
		$result=$this->api_model->getAllTickets();
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function getTicketsbyMonth_post(){
			 $id=$this->post('id');
		$result=$this->api_model->getTicketsbyMonth($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function getTicketsbyDay_post(){
			 $id=$this->post('id');
		$result=$this->api_model->getTicketsbyDay($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

	public function getTicketsbyWeek_post(){
		$id=$this->post('id');
		$result=$this->api_model->getTicketsbyWeek($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);
		}
	}

	public function deleteTicket_post(){
		$id= $this->post('qid');
		$result=$this->api_model->deleteTicket($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}

	public function getTktsByType_post(){
		$type=$this->post('status');
		$user_id=$this->post('user_id');

		$result= $this->api_model->getTktsByType($type,$user_id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}

	public function myDailyWorkUpdate_post(){
		//$lecture_ids= $this->post('lecture_id');

		$data = $this->post('lecture_id');

		for($i=0;$i<sizeof($data);$i++){
		 	$update_Data=$this->db->query('UPDATE facultywork SET status=1 WHERE lecture_id="'.$data[$i].'"');
		}

		if($update_Data){
			return $this->response($update_Data,200);
		}
		else{
			return $this->response($update_Data,400);
		}

		}

	public function procedureExample_get(){
		$result= $this->db->query('call get_employees()')->result();
		if($result){
			return $this->response($result,200);
		}
	}

	public function deleteDailywork_post(){
		$id= $this->post('id');
		$result=$this->api_model->deleteDailywork($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}


	public function getTktsByType_mwd_post(){
		$status=$this->post('status');
		$user_id=$this->post('user_id');
		$type_tkts=$this->post('type_tkts');

		$result= $this->api_model->getTktsByType_mwd($status,$user_id,$type_tkts);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}

	public function getTeamTktsbyId_post(){
		$start_dt=$this->post('sel_start_dt');
		$end_dt=$this->post('sel_end_dt');
		$seluserid=$this->post('seluserid');
		$selstatus=$this->post('selstatus');
		$login_id=$this->post('login_id');
		$result= $this->api_model->getTeamTktsbyId($start_dt,$end_dt,$seluserid,$selstatus,$login_id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}

	public function notificationTkts_post(){
		$user_id=$this->post('user_id');
		$result= $this->api_model->notificationTkts($user_id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}
	public function notificationReset_post(){
		$user_id=$this->post('user_id');

		$result= $this->api_model->notificationReset($user_id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no Ticket found',400);
		}
	}

	public function getUserprofile_post(){
		$user_id=$this->post('id');
		$result= $this->api_model->getUserprofile($user_id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);
		}
	}

public function changePassword_post(){

	$password =md5($this->post('password'));
	$oldpassword =md5($this->post('oldpassword'));
	$username =($this->post('username'));


	$result= $this->api_model->changePassword($password, $oldpassword, $username);
			if($result){
				return $this->response($result,200);
		}else{
				return $this->response('upadate fails',400);
		}
}



public function getAllTicketslead_post(){
			$id=$this->post('user_id');
		$result=$this->api_model->getAllTicketslead($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}


		public function getTicketsdemo_post(){
			$id=$this->post('user_id');
		$result=$this->api_model->getTicketsdemo($id);
		if($result){
			return $this->response($result,200);
		}else{
			return $this->response('no data found',400);		}
	}

public function updateTicket1_post(){

		$data['type'] =$this->post('type');
    	$data['task'] =$this->post('task');
		$data['ticket_id'] =$this->post('ticket_id');
		$data['task_desc'] =$this->post('task_desc');
		//11$data['assigned_by'] =$this->post('assigned_id');
		//$data['actual_st_date'] = $this->post('actual_st_date');
 	   //  11strtotime($this->post('actual_end_date'));
 	     //$date=strtotime($this->post('actual_end_date'));
 	     //$date1=date('Y-m-d',$date);
 	    //$data['actual_end_date'] =$date1;
		$data['assigned_to'] =$this->post('assigned_to');
		$data['status'] =$this->post('status');
		$data['comments'] =$this->post('comments');
	    $data['rating'] =$this->post('rating');
   	    $data['approve'] =$this->post('approve');
 		$tkt_update= $this->api_model->updateTicket($data);
		if($tkt_update){
				return $this->response($tkt_update,200);
		}else{
				return $this->response('upadate fails',400);
		}

	}

public function sendNoTimesheetMail_get(){
	$result= $this->api_model->sendNoTimesheetMail();
			if($result){
				return $this->response($result,200);
		}else{
				return $this->response('server error',400);
		}
}

// Ticket to employees reminding them that ticket is still in progress beyond
// end date
public function end_dateProgressMail_get(){
	$result= $this->api_model->end_dateProgressMail();
			if($result){
				return $this->response($result,200);
		}else{
				return $this->response('server error',400);
		}
}

// Ticket to leads reminding to close tickets
public function closeNotapproveMail_get(){
	$result= $this->api_model->closeNotapprove();
			if($result){
				return $this->response($result,200);
		}else{
				return $this->response('server error',400);
		}
}

public function submitNotapprovedMail_get(){
	$result= $this->api_model->submitNotapproved();
			if($result){
				return $this->response($result,200);
		}else{
				return $this->response('server error',400);
		}
}

     // save questions new
    public function savemcqquestions_post()
    {
    	$data['question'] =$this->post('question');
    	$data['subject'] =$this->post('subject');
    	$data['setno'] =$this->post('setno');
       // $question=$this->post('question');
       //  $subject=$this->post('subject');
       //   $setno=$this->post('setno');
      $result= $this->api_model->savemcqquestions($data);
	  return $this->response($result);
    }

     public function finalque_post()
    {
      $data['question'] =$this->post('question');
    	$data['subject'] =$this->post('subject');
    	$data['setno'] =$this->post('setno');
      $result= $this->api_model->finalque($data);
	  return $this->response($result);
    }
    public function savemcqquestions1_post()
    {
       $data=$this->post('qid');
      $result= $this->api_model->savemcqquestions1($data);
	  return $this->response($result);
    }

	    // get questions list
    public function getmcqquestions_get()
    {
      $result= $this->api_model->getmcqquestions();
	  return $this->response($result);
    }

     public function getmcqquestionslist_get()
    {
      $result= $this->api_model->getmcqquestionslist();
	  return $this->response($result);
    }

    public function getmcqquestionslist1_get()
    {
      $result= $this->api_model->getmcqquestionslist1();
	  return $this->response($result);
    }


    public function getmcqquestionslist2_get()
    {
      $result= $this->api_model->getmcqquestionslist2();
	  return $this->response($result);
    }
}
