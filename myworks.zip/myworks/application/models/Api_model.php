<?php
class Api_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
    }

    // validate login details
 public function loginCheck($username, $password)
 {
     $this->db->where('username', $username);
     $this->db->where('password', md5($password));
     $data = $this->db->get('users')->row();


     if ($data) {
         return $data;
     } else {
         return array("success"=>false, "error"=>$username);
     }
 }

    public function addTicket($param='')
    {
        $result= $this->db->insert('tickets', $param);
        return $result;
 // print_r($result);
    }

    public function updateTicket($param='')
    {
        //print_r($param);
     //echo $param->ticket_id;
     //echo $param['ticket_id'];

  $this->db->where('ticket_id', $param['ticket_id']);
        return $result= $this->db->update('tickets', $param);
  //print_r($result);
    }
    public function getTickets($param='')
    {
        //$tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,u.user_id,u.name FROM `tickets` t inner join users u on t.assigned_to=u.user_id and (t.assigned_by='.$param.' or t.assigned_to='.$param.') ')->result();

    $tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.comments,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,t.actual_st_date, t.actual_end_date, (SELECT name from users where user_id=t.assigned_by limit 1) as assigned_by_name, (SELECT name from users where user_id=t.assigned_to limit 1) as assigned_to_name FROM `tickets` t where (t.assigned_to="'.$param.'" or t.assigned_by="'.$param.'") ORDER BY t.ticket_id desc')->result();

        if ($tickets) {
            return $tickets;
        } else {
            return false;
        }
    }

    public function getTicketsByCategory($param='')
    {
        //echo $param;
  // echo 'hello';
 //$result=$this->db->query('select (SELECT count(*) FROM `tickets` where assigned_by=12) as assigned_by , (SELECT count(*) FROM `tickets` where assigned_to=12) as assigned_to, (select count(*)from tickets where assigned_by=12 or assigned_to=12) as total')->result();
   if ($param!='') {
       $result = $this->db->query('select (select count(*)from tickets where assigned_by="'.$param.'") as tot,(select count(*) from tickets where  assigned_by="'.$param.'" and status="assigned") as assign,(select count(*) from tickets where  assigned_by="'.$param.'"  and status="inprogress") as inprogress,(select count(*) from tickets where  assigned_by="'.$param.'" and status="close") as closed,(select count(*) from tickets where  assigned_by="'.$param.'" and status="hold") as hold')->result();
   } else {
       $result = $this->db->query("SELECT COUNT(case when status='assigned' then '' end ) as assign,
       COUNT(case when status='inprogress' then '' end) as inprogress,
       COUNT(case when status='close' then '' end) as closed,
       COUNT(case when status='hold' then '' end) as hold ,
       COUNT(*)  as tot
       from tickets")->result();
   }
        if ($result) {
            return $result;
        } else {
            return false;
        }
    }

    public function dailyWork($data, $desc1)
    {

      //print_r($desc1);
       // echo $desc1[0]['data'];
       //echo $desc1[1]['data'];
      // echo $desc1[2]['data'];
      //echo $desc1->data;
        $lecture_id = $data['lecture_id'];
        $date_of_start = $data['date_of_start'];
        $active_list = $data['active_list'];


        $sql = "insert into facultywork(reg_no, ticket_id, date_of_start, start_tm, end_tm, catagory, description,created_by,status,checked,task,project_status) values";
        for ($i=0; $i<sizeof($active_list); $i++) {
            $val = $active_list[$i];
            $dec = $desc1[$i]['data'];

            if (strlen(trim($val['description'])) > 0) {
                $sql .= "('" . $val['reg_no'] . "','" . $val['ticket_id'] . "','" . $date_of_start . "','" . $val['start_tm'] . "','" . $val['end_tm'] . "','" . $val['catagory'] . "','" . $dec . "','" . $val['created_by'] . "','" . $val['status'] . "','" . $val['checked'] . "','" .$val['task']. "','" .$val['project_status']. "'),";
            }
        }

        $sql = substr($sql, 0, strlen($sql)-1);

        if ($this->db->query($sql)) {
            return array("success" => true);
        } else {
            return array("success" => false);
        }
    }
    public function dailyWork1($data, $desc1)
    {

      //print_r($desc1);
       // echo $desc1[0]['data'];
       //echo $desc1[1]['data'];
      // echo $desc1[2]['data'];
      //echo $desc1->data;
        $lecture_id = $data['lecture_id'];
        $date_of_start = $data['date_of_start'];
        $active_list = $data['active_list'];


        $sql = "insert into dialystatus(username, working_on, today_task, status, tomorrows_plan) values";
        for ($i=0; $i<sizeof($active_list); $i++) {
            $val = $active_list[$i];
            $dec = $desc1[$i]['data'];

            if (strlen(trim($val['description'])) > 0) {
                $sql .= "('" . $val['username'] . "','" . $val['working_on'] . "','" . $date_of_start . "','" . $val['today_task'] . "','" . $val['status'] . "','" . $val['tomorrows_plan'] . "'),";
            }
        }

        $sql = substr($sql, 0, strlen($sql)-1);

        if ($this->db->query($sql)) {
            return array("success" => true);
        } else {
            return array("success" => false);
        }
    }


    public function getDailyWork($reg_no, $param1='', $param2='', $param3='')
    {
        if ($reg_no == 'all' && $param1=='' && $param2=='' && $param3 =='') {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id  order by reg_no";
        } elseif ($reg_no == 'all' && $param1!='' && $param2!='' && $param3 =='2') {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and f.date_of_start BETWEEN '".$param1."' and '".$param2."'    order by lecture_id desc";
        } elseif ($reg_no == 'all' && $param1!='' && $param2!='' && $param3 !='2') {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and f.date_of_start BETWEEN '".$param1."' and '".$param2."' and f.status='$param3'    order by lecture_id desc";
        } elseif ($reg_no != 'all' && $param1!='' && $param2!='' && $param3=='2') {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and reg_no='$reg_no' and f.date_of_start BETWEEN '".$param1."'  and '".$param2."'  order by lecture_id desc ";
        } elseif ($reg_no != 'all' && $param1!='' && $param2!='' && $param3!='2') {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and reg_no='$reg_no' and f.date_of_start BETWEEN '".$param1."'  and '".$param2."' and f.status='$param3'  order by lecture_id desc ";
        } else {
            $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and reg_no='$reg_no' ";
        }
        $query = $this->db->query($sql);
        $result = $query->result();

        return array("success" => true, "data" => $result);
    }


   // public function getDailyWork($reg_no)
   //  {
   //      if($reg_no == 'all'){
   //      $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id  order by reg_no";
   //      }else{
   //      $sql = "SELECT f.*,u.name from facultywork f INNER JOIN users u where f.reg_no =u.user_id and reg_no='$reg_no' ";
   //      }
   //      $query = $this->db->query($sql);
   //      $result = $query->result();

   //      return array("success" => true, "data" => $result);
   //  }


    public function getAllTickets($param='')
    {
        //$tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,u.user_id,u.name FROM `tickets` t inner join users u on t.assigned_to=u.user_id and (t.assigned_by='.$param.' or t.assigned_to='.$param.') ')->result();
    $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to_name  FROM tickets t  INNER JOIN users u on t.assigned_by=u.user_id INNER join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role')->result();

        if ($tickets) {
            return $tickets;
        } else {
            return false;
        }
    }

    public function getTicketsbyMonth($param='')
    {
        if ($param=='') {
            $mon_tkts_assign_by= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE   MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
            $mon_tkts_assign_to= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE   MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
        } else {
            $mon_tkts_assign_by= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_by="'.$param.'") AND MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
            $mon_tkts_assign_to= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_to="'.$param.'") AND MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
        }

   // $mon_tkts_assign_by= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_by="'.$param.'") AND MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
    //$mon_tkts_assign_to= $this->db->query('SELECT  Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_to="'.$param.'") AND MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();

    if ($mon_tkts_assign_by || $mon_tkts_assign_to) {
        return array("success" => true, "data" => $mon_tkts_assign_by,"data1" => $mon_tkts_assign_to);
    } else {
        return false;
    }
    }

    public function getTicketsbyDay($param='')
    {
        if ($param=='') {
            $day_tkts_assign_by= $this->db->query('SELECT   Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE   start_dt=DATE(NOW())')->result();
            $day_tkts_assign_to= $this->db->query('SELECT   Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE   start_dt=DATE(NOW())')->result();
        } else {
            $day_tkts_assign_by= $this->db->query('SELECT   Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_by="'.$param.'") and start_dt=DATE(NOW())')->result();
            $day_tkts_assign_to= $this->db->query('SELECT   Count(*) As tot,Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_to="'.$param.'") and start_dt=DATE(NOW())')->result();
        }

        if ($day_tkts_assign_by || $day_tkts_assign_to) {
            return array("success" => true, "data" => $day_tkts_assign_by,"data1" => $day_tkts_assign_to);
        } else {
            return false;
        }
    }

    public function getTicketsbyWeek($param='')
    {
        if ($param=='') {
            $week_tkts_assign_by= $this->db->query('SELECT   Count(*) As tot, Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE    WEEKOFYEAR(start_dt)=WEEKOFYEAR(now())')->result();
            $week_tkts_assign_to= $this->db->query('SELECT   Count(*) As tot, Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE    WEEKOFYEAR(start_dt)=WEEKOFYEAR(now())')->result();
        } else {
            $week_tkts_assign_by= $this->db->query('SELECT   Count(*) As tot, Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_by="'.$param.'") and  WEEKOFYEAR(start_dt)=WEEKOFYEAR(now())')->result();
            $week_tkts_assign_to= $this->db->query('SELECT   Count(*) As tot, Count(case when status="assigned" then "" end) As assign, Count(case when status="inprogress" then "" end) As inprogress, Count(case when status="close" then "" end) As closed , Count(case when status="hold" then "" end) As hold FROM tickets WHERE (assigned_to="'.$param.'") and  WEEKOFYEAR(start_dt)=WEEKOFYEAR(now())')->result();
        }
        if ($week_tkts_assign_by || $week_tkts_assign_to) {
            return array("success" => true, "data" => $week_tkts_assign_by,"data1" => $week_tkts_assign_to);
        } else {
            return false;
        }
    }

    public function deleteTicket($param='')
    {
        $del= $this->db->query('delete from question where qid="'.$param.'"');
        if ($del) {
            return $del;
        } else {
            return false;
        }
    }

    public function getTktsByType($param='', $user_id='')
    {
        if ($param=='total' && $user_id=='') {
            $tkts=$this->db->query("SELECT t.*,u.name as assigned_by,u1.name assigned_to from tickets t INNER JOIN users u on u.user_id=t.assigned_by INNER JOIN users u1 ON u1.user_id=t.assigned_to  ORDER BY t.status ")->result();
        } elseif ($param!='total' && $user_id=='') {
            $tkts=$this->db->query("SELECT t.*,u.name as assigned_by,u1.name assigned_to from tickets t INNER JOIN users u on u.user_id=t.assigned_by INNER JOIN users u1 ON u1.user_id=t.assigned_to   where t.status='".$param."' ")->result();
        } elseif ($param=='total' && $user_id!='') {
            $tkts=$this->db->query("SELECT t.*,u.name as assigned_by,u1.name assigned_to from tickets t INNER JOIN users u on u.user_id=t.assigned_by INNER JOIN users u1 ON u1.user_id=t.assigned_to   where t.assigned_by='".$user_id."' ")->result();
        } elseif ($param!='total' && $user_id!='') {
            $tkts=$this->db->query("SELECT t.*,u.name as assigned_by,u1.name assigned_to from tickets t INNER JOIN users u on u.user_id=t.assigned_by INNER JOIN users u1 ON u1.user_id=t.assigned_to   where t.status='".$param."' and t.assigned_by='".$user_id."' ")->result();
        } else {
        }
        if ($tkts) {
            return $tkts;
        } else {
            return false;
        }
    }
    public function deleteDailywork($param='')
    {
        $del= $this->db->query('delete from facultywork where lecture_id="'.$param.'"');
        if ($del) {
            return $del;
        } else {
            return false;
        }
    }

    public function getTktsByType_mwd($status='', $user_id='', $type_tkts='')
    {
        if ($user_id!='') {
            switch ($type_tkts) {
      case 'mwts':
        # code...
      if ($status=='total') {
          $tkts=$this->db->query('SELECT *FROM tickets WHERE MONTH(CURRENT_DATE())=MONTH(start_dt) AND  assigned_to="'.$user_id.'"')->result();
      } else {
          $tkts=$this->db->query('SELECT *FROM tickets WHERE MONTH(CURRENT_DATE())=MONTH(start_dt) AND status="'.$status.'" and assigned_to="'.$user_id.'"')->result();
      }
      break;

      case 'wwts':
        # code...
      if ($status=='total') {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE WEEKOFYEAR(start_dt)=WEEKOFYEAR(now()) AND assigned_to="'.$user_id.'"')->result();
      } else {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE WEEKOFYEAR(start_dt)=WEEKOFYEAR(now()) AND status="'.$status.'" and assigned_to="'.$user_id.'"')->result();
      }

      break;

      case 'dwts':
        # code...
      if ($status=='total') {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE SUBSTR(start_dt,1,10)=DATE(NOW()) AND  assigned_to="'.$user_id.'"')->result();
      } else {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE SUBSTR(start_dt,1,10)=DATE(NOW()) AND status="'.$status.'" and assigned_to="'.$user_id.'"')->result();
      }
      break;

      default:
        # code...
      break;
    }
        } else {
            switch ($type_tkts) {
      case 'mwts':
        # code...
      if ($status=='total') {
          $tkts=$this->db->query('SELECT *FROM tickets WHERE MONTH(CURRENT_DATE())=MONTH(start_dt)')->result();
      } else {
          $tkts=$this->db->query('SELECT *FROM tickets WHERE MONTH(CURRENT_DATE())=MONTH(start_dt) AND status="'.$status.'" ')->result();
      }
      break;

      case 'wwts':
        # code...
      if ($status=='total') {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE WEEKOFYEAR(start_dt)=WEEKOFYEAR(now()) ')->result();
      } else {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE WEEKOFYEAR(start_dt)=WEEKOFYEAR(now()) AND status="'.$status.'" ')->result();
      }

      break;

      case 'dwts':
        # code...
      if ($status=='total') {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE SUBSTR(start_dt,1,10)=DATE(NOW()) ')->result();
      } else {
          $tkts = $this->db->query('SELECT *FROM tickets WHERE SUBSTR(start_dt,1,10)=DATE(NOW()) AND status="'.$status.'" ')->result();
      }
      break;



    }
        }

        if ($tkts) {
            return $tkts;
        } else {
            return false;
        }
    }

    public function getTeamTktsbyId($param1='', $param2='', $param3='', $param4='', $param5='')
    {
        if ($param3=="all" && $param4=="all") {
            $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to_name  FROM tickets t  LEFT JOIN users u on t.assigned_by=u.user_id LEFT join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role
  where  substr(start_dt,1,10) >= "'.$param1.'"  and substr(end_dt,1,10) <="'.$param2.'" and t.assigned_by="'.$param5.'"  ORDER BY t.ticket_id desc')->result();
        } elseif ($param3!="all" && $param4=="all") {
            $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to_name  FROM tickets t  LEFT JOIN users u on t.assigned_by=u.user_id LEFT join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role
  where  substr(start_dt,1,10) >= "'.$param1.'"  and substr(end_dt,1,10) <="'.$param2.'" and t.assigned_to="'.$param3.'" and t.assigned_by="'.$param5.'" ORDER BY t.ticket_id desc')->result();
        } elseif ($param3=="all" && $param4!="all") {
            $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to_name  FROM tickets t  LEFT JOIN users u on t.assigned_by=u.user_id LEFT join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role
  where  substr(start_dt,1,10) >= "'.$param1.'"  and substr(end_dt,1,10) <="'.$param2.'" and t.status="'.$param4.'" and t.assigned_by="'.$param5.'" ORDER BY t.ticket_id desc')->result();
        } else {
            $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_by_name  FROM tickets t  LEFT JOIN users u on t.assigned_by=u.user_id LEFT join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role
  where  substr(start_dt,1,10) >= "'.$param1.'"  and substr(end_dt,1,10) <="'.$param2.'" and t.assigned_to="'.$param3.'" and t.assigned_by="'.$param5.'" and t.status="'.$param4.'" ORDER BY t.ticket_id desc')->result();
        }
  // $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to  FROM tickets t  LEFT JOIN users u on t.assigned_by=u.user_id LEFT join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role
  // where  substr(start_dt,1,10) >= "'.$param1.'"  and substr(end_dt,1,10) <="'.$param2.'" and t.assigned_to="'.$param3.'" and t.status="'.$param3.'" ORDER BY t.ticket_id desc')->result();


    if ($tickets) {
        return $tickets;
    } else {
        return false;
    }
    }

    public function notificationTkts($param1='')
    {
        $notifications= $this->db->query(' SELECT count(*) as notifications FROM tickets WHERE   assigned_to="'.$param1.'" and alert_status="1" ')->result();
        if ($notifications) {
            return $notifications;
        } else {
            return false;
        }
    }

    public function notificationReset($param1='', $param2='')
    {
        $this->db->set('alert_status', 0);
        $this->db->where('assigned_to', $param1);
        $notifications = $this->db->update('tickets');
  //$notifications= $this->db->query(' SELECT count(*) as notifications FROM tickets WHERE SUBSTR(start_dt,1,10)=DATE(NOW()) and assigned_to="'.$param1.'" ')->result();
    if ($notifications) {
        return $notifications;
    } else {
        return false;
    }
    }

    public function getUserprofile($param1='')
    {
        $result= $this->db->query('SELECT * FROM `users` where user_id="'.$param1.'"')->row();
        if ($result) {
            return $result;
        } else {
            return false;
        }
    }



    public function changePassword($param1='', $param2='', $param3='')
    {
        $result= $this->db->query('UPDATE users SET password="'.$param1.'" where user_id="'.$param3.'" and  password="'.$param2.'"');
        if ($result) {
            return $result;
        } else {
            return false;
        }
    }

    public function getAllTicketslead($param='')
    {
        //$tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,u.user_id,u.name FROM `tickets` t inner join users u on t.assigned_to=u.user_id and (t.assigned_by='.$param.' or t.assigned_to='.$param.') ')->result();
    $tickets= $this->db->query('SELECT t.*, u.user_id,u.name,u.role,u1.name as assigned_to_name FROM tickets t INNER JOIN users u on t.assigned_by=u.user_id INNER join users u1 on t.assigned_to=u1.user_id and t.created_by=u.role WHERE u.user_id="'.$param.'" ORDER BY t.ticket_id desc')->result();

        if ($tickets) {
            return $tickets;
        } else {
            return false;
        }
    }





    public function getTicketsdemo($param='')
    {
        //$tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,u.user_id,u.name FROM `tickets` t inner join users u on t.assigned_to=u.user_id and (t.assigned_by='.$param.' or t.assigned_to='.$param.') ')->result();

    // $tickets= $this->db->query('SELECT t.ticket_id,t.task,t.category,t.comments,t.taskpriority,t.task_desc,t.start_dt,t.end_dt,t.hrs,t.assigned_by,t.assigned_to,t.status,t.actual_st_date, t.actual_end_date, (SELECT name from users where user_id=t.assigned_by limit 1) as assigned_by_name, (SELECT name from users where user_id=t.assigned_to limit 1) as assigned_to_name FROM `tickets` t where (t.assigned_to="'.$param.'" or t.assigned_by="'.$param.'")')->result();

$tickets= $this->db->query("SELECT  ticket_id FROM tickets where assigned_to='$param' and (status ='inprogress' or (status='close' and (actual_end_date =CURDATE() or actual_end_date=subdate(curdate(), 1) )))")->result();

        if ($tickets) {
            return $tickets;
        } else {
            return false;
        }
    }

    // Reminder to employees to submit their timesheetsd
    public function sendNoTimesheetMail()
    {
        $mails= $this->db->query("select username, email from users where username not in(SELECT distinct created_by FROM `facultywork` WHERE date_of_start = date(now())) and username not in ('admin', 'ramakrishna.cp', 'tejeswar.s', 'nikhil.i', 'sravan.r')
")->result();

        if ($mails) {
            $to = '';
            foreach ($mails as $key=>$val) {
                $to .= $val->email . ',';
            }

// $to = 'vijay.m@akrivia.in,raju.dl@akrivia.in';
$subject = 'Timesheet not submitted';
            $message = 'This is a reminder to submit your timesheet by the end of the day';

            $params = array(
'to' => $to,
'subject' => $subject,
'message' => $message
);

$cc = '';
            return $this->sendEmail($to, $cc, $subject, $message);
        } else {
            return false;
        }
    }

    // Tickets which are open beyond given end date
    public function end_dateProgressMail()
    {
        $mails= $this->db->query("select  group_concat(t.ticket_id) as ticket_id, u.email, t.task_desc as task1, group_concat(t.task_desc,'~') as task_desc,(group_concat(date(t.end_dt))) as end_dt from tickets t INNER join users u on assigned_to=u.user_id where end_dt < CURRENT_DATE and status='inprogress' group by email  ORDER BY `u`.`email` ASC")->result();

        if ($mails) {
            $to = '';
            $subject = '';
            $message = '';
            $cc = '';
            foreach ($mails as $key=>$val) {
                $to = $val->email;

    // $to = 'vijay.m@akrivia.in,raju.dl@akrivia.in';
            $subject = 'Ticket No. ' . $val->ticket_id . ' still in progress';
            $message = '<p>The following tickets are open beyond their assigned end date. Please close them as early as possible.</p>
            <table cellspacing=0 cellpadding=4 border=0>
            <tr>
            <th>
            Ticket ID
            </th>
            <th>
            Task Description
            </th>
            <th>
            Due Date
            </th>
            </tr>';

            $arrTickets = explode(',', $val->ticket_id);
            $arrTasks = explode('~,', $val->task_desc);
            $arrDates = explode(',', $val->end_dt);

            for ($i=0; $i<sizeof($arrTickets); $i++) {
              $task = str_replace('~', '', $arrTasks[$i]);
              $message .= '<tr><td>' . $arrTickets[$i] . '</td><td>' . $task . '</td><td>' . $arrDates[$i] . '</td><td></tr>';
            }


            // $message .= '<tr>
            //  <td>' . $val->ticket_id .'</td>
            // <td>' . $val->task1 .'</td>
            // <td>' . $val->end_dt .'</td>
            //  </tr>';

            $message .= '</table>';
            $this->sendEmail($to, $cc, $subject, $message);
            }
            return true;
        } else {
            return false;
        }
    }

    // Tickets closed but not approved. Email to leads
    public function closeNotapprove()
    {
        $mails= $this->db->query("select GROUP_CONCAT(t.ticket_id) as ticket_id, u.email from tickets t  INNER join users u on assigned_by=u.user_id where approve = 'Pending' and status='close' group by email")->result();

        if ($mails) {
            $to = '';
            $subject = '';
            $message = '';
            $cc = '';
            foreach ($mails as $key=>$val) {
                $to .= $val->email . ',';


// $to = 'vijay.m@akrivia.in,raju.dl@akrivia.in';
            $subject = 'Tickets closed but not approved';
            $message = 'Tickets - ' . $val->ticket_id . ' assigned by you are closed. Please approve the tickets as soon as possible.';
}

            $params = array(
            'to' => $to,
            'subject' => $subject,
            'message' => $message
            );
            return $this->sendEmail($to, $cc, $subject, $message);
        } else {
            return false;
        }
    }

    // Use it in the future
    public function submitNotapproved()
    {
        $mails= $this->db->query("select u.username,f.start_tm,f.end_tm,f.status from users u inner join facultywork f on f.reg_no=u.user_id where f.status='0'")->result();

        if ($mails) {
            $to = '';
            $cc = '';
            foreach ($mails as $key=>$val) {
                $to .= $val->email . ',';
            }

// $to = 'vijay.m@akrivia.in,raju.dl@akrivia.in';
$subject = 'Time sheet submitted but not approved';
            $message = 'This is a reminder to approve the submitted timesheet list';

            $params = array(
              'to' => $to,
              'subject' => $subject,
              'message' => $message
            );
            return $this->sendEmail($to, $cc, $subject, $message);
        } else {
            return false;
        }
    }



    public function sendEmail($to, $cc, $subject, $message)
    {
        $from_email = 'noreply@akrivia.com';
        $subject = $subject;
        $message = $message;

        //configure email settings

        $this->load->library('email');
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'mail.akrivia.in'; //smtp host name
        $config['smtp_port'] = '587'; //smtp port number
        $config['smtp_user'] = 'hr1@akrivia.in';
        $config['smtp_pass'] = 'Akv@123'; //$from_email password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = true;
        $config['newline'] = "\r\n"; //use double quotes
        $this->email->initialize($config);

        //send mail
        $this->email->from($from_email, 'Akrivia');
        $this->email->to($to);
        $this->email->cc($cc);
        $this->email->bcc('vijay.m@akrivia.in, raju.dl@akrivia.in');
//        console.log($email,'email');
        $this->email->subject($subject);
        $this->email->message($message);
        return $this->email->send();
    }


      // Use it in the future
//     public function savemcqquestions($param1='', $param2='', $param3='')
//     {

// $result=$this->db->query('INSERT INTO `questions`( `question`,`subject`,`setno`) VALUES ("'.$param1.'","'.$param2.'","'.$param3.'")');
//         if ($result) {
//             return $result;
//         } else {
//             return false;
//         }
//     }

     public function savemcqquestions($param='')
    {
        $result= $this->db->insert('questions', $param);
        return $result;
 // print_r($result);
    }

    public function finalque($param='')
    {

        $result= $this->db->insert('list', $param);
        return $result;
    }
   
         

       // Use it in the future
    public function getmcqquestions()
    {

     return  $this->db->query("select * from questions")->result();
       
    }

    public function getmcqquestionslist()
    {

     return  $this->db->query("select * from list where setno=1 ORDER BY RAND() LIMIT 3  ")->result();
       return'';
    }

    public function getmcqquestionslist1()
    {

     return  $this->db->query("select * from list where setno=2 ORDER BY RAND() LIMIT 3  ")->result();
       return'';
    }

    public function getmcqquestionslist2()
    {

     return  $this->db->query("select * from list where setno=3 ORDER BY RAND() LIMIT 3  ")->result();
       return'';
    }

}
