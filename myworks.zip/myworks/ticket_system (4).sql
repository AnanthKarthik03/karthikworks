-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2017 at 12:33 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `facultywork`
--

CREATE TABLE `facultywork` (
  `lecture_id` int(11) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `date_of_start` date NOT NULL,
  `start_tm` varchar(255) NOT NULL,
  `end_tm` varchar(255) NOT NULL,
  `catagory` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `task` varchar(256) NOT NULL,
  `project_status` varchar(256) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `status` int(16) NOT NULL,
  `checked` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facultywork`
--

INSERT INTO `facultywork` (`lecture_id`, `reg_no`, `date_of_start`, `start_tm`, `end_tm`, `catagory`, `description`, `task`, `project_status`, `created_by`, `status`, `checked`) VALUES
(202, '8', '2017-05-22', '8:30 AM', '8:30 AM', 'project', 'discussion on new project', '', '', 'rambabu', 1, 0),
(203, '8', '2017-05-22', '9:00 AM', '9:45 AM', 'training', 'Training on new project', '', '', 'rambabu', 1, 0),
(204, '8', '2017-05-22', '10:00 AM', '10:45 AM', 'system_admin', 'System requirements for new project', '', '', 'rambabu', 1, 0),
(205, '8', '2017-05-22', '11:00 AM', '12:00 PM', 'hr_corporate_maintenance', 'Time schedule', '', '', 'rambabu', 1, 0),
(206, '12', '2017-05-23', '9:00 AM', '5:30 PM', 'project', 'test', '', '', 'dlp raju', 1, 0),
(207, '8', '2017-05-23', '8:30 AM', '8:45 AM', 'project', 'new project', '', '', 'rambabu', 1, 0),
(208, '8', '2017-05-23', '8:45 AM', '9:00 AM', 'training', 'training on new project ', '', '', 'rambabu', 1, 0),
(210, '8', '0000-00-00', '9:00 AM', '9:30 AM', 'project', 'asfssd', '', '', 'rambabu', 1, 0),
(213, '8', '2017-05-23', '8:30 AM', '8:30 AM', 'project', 'new project', '', '', 'rambabu', 0, 1),
(214, '8', '2017-05-25', '8:30 AM', '12:30 PM', 'training', 'training on node js', '', '', 'rambabu', 0, 1),
(215, '15', '2017-05-26', '8:30 AM', '10:00 AM', 'project', 'project analysis', '', '', 'sai', 0, 1),
(216, '15', '2017-05-26', '10:00 AM', '11:30 AM', 'project', 'planning', '', '', 'sai', 0, 1),
(217, '15', '2017-05-26', '11:45 AM', '12:45 PM', 'system_admin', 'start implementation', '', '', 'sai', 1, 1),
(218, '15', '2017-05-26', '12:45 PM', '1:30 PM', 'any_other', 'lunch break', '', '', 'sai', 1, 1),
(224, '15', '2017-05-26', '8:30 AM', '8:30 AM', 'project', 'new project', '', '', 'sai', 0, 1),
(225, '8', '2017-05-30', '8:30 AM', '8:30 AM', 'project', 'new project', '', '', 'rambabu', 0, 1),
(226, '8', '2017-05-30', '8:30 AM', '9:30 AM', 'training', 'fgh', '', '', 'rambabu', 0, 1),
(227, '8', '2017-05-30', '8:30 AM', '11:30 AM', 'project', 'sdfsd', '', '', 'rambabu', 0, 1),
(228, '15', '2017-05-30', '8:30 AM', '8:30 AM', 'project', 'sfsdf', '', '', 'sai', 0, 1),
(229, '15', '2017-05-31', '8:30 AM', '1:00 PM', 'project', 'bug fixes', '', '', 'sai', 0, 1),
(230, '16', '2017-05-31', '8:30 AM', '9:15 AM', 'project', 'new project', '', '', 'bhaskar', 1, 1),
(231, '16', '2017-05-31', '9:30 AM', '10:30 AM', 'project', 'planning', '', '', 'bhaskar', 0, 1),
(232, '8', '2017-06-13', '8:30 AM', '9:00 AM', 'project', 'modifications', 'ticket_system', 'inprogress', 'rambabu', 0, 1),
(233, '8', '2017-06-13', '8:30 AM', '8:30 AM', 'project', 'modifications', 'ticket_system', 'inprogress', 'rambabu', 0, 1),
(234, '8', '2017-06-06', '8:30 AM', '8:30 AM', 'hr corp maintain', 'fsfsfsfsfsf', 'werwe', 'rwe', 'rambabu', 0, 1),
(235, '8', '2017-06-06', '9:45 AM', '11:15 AM', 'system_admin', 'sfsfs', 'asfsfsfs', 'sfsdfs', 'rambabu', 0, 1),
(236, '8', '2017-06-13', '8:30 AM', '8:30 AM', 'project', 'sdfsf', 'sfs', 'fsfsf', 'rambabu', 0, 1),
(237, '8', '2017-06-06', '8:30 AM', '8:30 AM', 'project', 'sfsdfsf', 'asfs', 'sf', 'rambabu', 0, 1),
(238, '8', '2017-06-07', '8:30 AM', '8:30 AM', 'project', 'sfasfsf', 'sfsfs', 'sdafsfsf', 'rambabu', 1, 1),
(239, '8', '2017-06-06', '8:30 AM', '8:30 AM', 'project', 'sdfsfsd', 'sdsdf', 'sdfsd', 'rambabu', 0, 1),
(240, '8', '2017-06-06', '8:30 AM', '8:30 AM', 'project', 'asdsa', 'as', 'aad', 'rambabu', 0, 1),
(241, '8', '0000-00-00', '8:30 AM', '8:30 AM', 'project', 'sdfsf', 'fa', 'sfs', 'rambabu', 0, 1),
(242, '', '2017-06-07', '9:15 AM', '9:00 AM', 'training', 'sfsdf', 'sfsf', 'sfsf', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `task` varchar(256) NOT NULL,
  `category` varchar(128) NOT NULL,
  `type` varchar(128) NOT NULL,
  `taskpriority` varchar(64) NOT NULL,
  `task_desc` text NOT NULL,
  `start_dt` datetime NOT NULL,
  `end_dt` datetime NOT NULL,
  `actual_st_date` varchar(32) NOT NULL,
  `actual_end_date` varchar(32) NOT NULL,
  `hrs` varchar(32) NOT NULL,
  `assigned_by` varchar(128) NOT NULL,
  `assigned_to` varchar(128) NOT NULL,
  `status` varchar(32) NOT NULL,
  `comments` varchar(128) NOT NULL,
  `alert_status` int(2) NOT NULL,
  `created_by` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `task`, `category`, `type`, `taskpriority`, `task_desc`, `start_dt`, `end_dt`, `actual_st_date`, `actual_end_date`, `hrs`, `assigned_by`, `assigned_to`, `status`, `comments`, `alert_status`, `created_by`) VALUES
(118, 'project', 'New Development', 'new project', 'high', 'assign me a  new project', '2017-06-07 00:00:00', '2017-06-07 00:00:00', 'Tue Jun 06 2017 10:54:31 AM', 'Tue Jun 06 2017 10:56:12 AM', '4', '8', '12', 'close', 'good', 0, 'user'),
(120, 'training', 'In-house', 'asfsf', 'high', 'safsfsdfsd', '2017-06-06 15:25:00', '2017-06-07 06:30:00', '', '', '2', '11', '13', 'assigned', '', 0, 'admin'),
(121, 'any_other', 'others', 'asdasd', 'low', 'afsfdfsd', '2017-06-06 06:30:00', '2017-06-08 06:05:00', '', '', '1', '11', '13', 'assigned', '', 0, 'admin'),
(122, 'system_admin', 'Software', 'sdfas', 'medium', 'asfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjfasfsafsafsaklfsaj;flskfl;skfsl;kfsal;fkasjl;kvn;laskd;lfksjf', '2017-06-06 06:10:00', '2017-06-06 15:30:00', '', '', '1', '11', '13', 'assigned', '', 0, 'admin'),
(123, 'training', 'Workshop', 'asfs', 'low', 'asfsfsfsdsfsd', '2017-06-01 02:10:00', '2017-06-07 05:25:00', '', '', '1', '11', '23', 'assigned', '', 1, 'admin'),
(124, 'system_admin', 'Hardware', 'asfsf', 'low', 'asfsfsf', '2017-05-31 03:15:00', '2017-05-31 06:30:00', '', '', '1', '11', '18', 'assigned', '', 1, 'admin'),
(125, 'training', 'In-house', 'sdfsfd', 'high', 'need new project', '2017-06-01 01:05:00', '2017-06-02 01:05:00', '', '', '2', '8', '18', 'assigned', 'bhaskar include him in project', 0, 'user'),
(126, 'project', 'New Development', 'adaa', 'high', 'sdfsfsdfsd', '2017-06-06 08:55:00', '2017-06-07 18:50:00', 'Wed Jun 07 2017 2:00:13 PM', '', '8', '11', '12', 'inprogress', 'sdfsf', 0, 'admin'),
(127, 'project', 'Enhancements', 'tkt system', 'high', 'there are some enhancements', '2017-06-07 14:55:00', '2017-06-07 19:55:00', '', '', '4', '13', '11', 'assigned', '', 0, 'lead');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `employee_id` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user',
  `name` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `employee_id`, `role`, `name`, `email`) VALUES
(8, 'rambabu', '81dc9bdb52d04dc20036dbd8313ed055', '8', 'user', 'rambabu', 'rambabu90@yahoo.com'),
(11, 'sriram', '81dc9bdb52d04dc20036dbd8313ed055', '11', 'admin', 'admin', 'sriram@gmail.com'),
(12, 'lead1', '81dc9bdb52d04dc20036dbd8313ed055', '12', 'lead', 'lead1', 'dlpraju@gmail.com'),
(13, 'lead2', '81dc9bdb52d04dc20036dbd8313ed055', '13', 'lead', 'lead2', 'kalyan@gmail.com'),
(14, 'srinadh', '81dc9bdb52d04dc20036dbd8313ed055', '14', 'user', 'srinadh jagarapu', 'srinadh@gmail.com'),
(15, 'sai', '81dc9bdb52d04dc20036dbd8313ed055', '15', 'user', 'sai', 'sai@yahoo.com'),
(16, 'bhaskar', '827ccb0eea8a706c4c34a16891f84e7b', '', 'user', 'bhaskar', 'bhaskar@gmail.com'),
(17, 'karthik', '827ccb0eea8a706c4c34a16891f84e7b', '', 'user', 'karthik', 'karthik@gmail.com'),
(18, 'bhaskar', '827ccb0eea8a706c4c34a16891f84e7b', '', 'user', 'bhaskar', 'bhaskar@gmail.com'),
(19, 'intern1.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern1.it', 'intern1.it@gmail.com'),
(20, 'intern2.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern2.it', 'intern2.it@gmail.com'),
(21, 'intern3.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern3.it', 'intern3.it@gmail.com'),
(22, 'intern4.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern4.it', 'intern4.it@gmail.com'),
(23, 'intern5.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern5.it', 'intern5.it@gmail.com'),
(24, 'intern6.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern6.it', 'intern6.it@gmail.com'),
(25, 'intern7.it', '4b53351b2bd4a43eec4f5c64efad046e\r\n', '', 'user', 'intern7.it', 'intern7.it@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `facultywork`
--
ALTER TABLE `facultywork`
  ADD PRIMARY KEY (`lecture_id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `facultywork`
--
ALTER TABLE `facultywork`
  MODIFY `lecture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;
--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
