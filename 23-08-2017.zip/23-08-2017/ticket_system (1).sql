-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 23, 2017 at 02:47 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `qid` int(11) NOT NULL,
  `college` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `year` int(10) NOT NULL,
  `mid` int(10) NOT NULL,
  `sem` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`qid`, `college`, `dept`, `year`, `mid`, `sem`, `sub`, `date`) VALUES
(1, 'rec', 'ELECTRICAL AND ELECTRONICS ENGINEERING', 4, 1, 2, 'COMPUTER ORGANIZATION', '2017-08-23');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(10) NOT NULL,
  `question` longtext NOT NULL,
  `subject` varchar(20) NOT NULL,
  `setno` int(5) NOT NULL,
  `level` varchar(10) NOT NULL,
  `checked` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `question`, `subject`, `setno`, `level`, `checked`) VALUES
(1, 'What is Geology? Explain in brief about different branches of Geology.', 'ENGINEERING GEOLOGY', 1, 'easy', 1),
(2, 'a.What is the importance of Geology in Civil Engineering?<br>\r\n b.What is weathering and explain the importance of weathering.', 'ENGINEERING GEOLOGY', 1, 'medium', 1),
(3, 'Briefly explain the case history of failures of some civil engineering structures due to geological drawbacks.', 'ENGINEERING GEOLOGY', 1, 'hard', 1),
(4, 'Explain the factors responsible for weathering and also explain about the process of Geological agents.', 'ENGINEERING GEOLOGY', 1, 'easy', 1),
(6, 'a.What are the requirements to be fulfilled by a substance to call it as a mineral?\r\n <br>b.What are the different methods of study of a mineral?', 'ENGINEERING GEOLOGY', 2, 'medium', 1),
(7, 'Explain different physical properties of a mineral and also give the properties of   KYANITE, HORNBLENDE, FELDSPAR.', 'ENGINEERING GEOLOGY', 2, 'easy', 1),
(9, 'Explain briefly about sedimentary and metamorphic rocks.', 'ENGINEERING GEOLOGY', 2, 'hard', 1),
(10, 'Explain briefly about the types, structures, textures and forms of Igneous rocks.', 'ENGINEERING GEOLOGY', 2, 'hard', 1),
(11, 'a. What is an Outcrop?<br>b.What are discussed in structural geology', 'ENGINEERING GEOLOGY', 3, 'easy', 1),
(12, 'What is a Fold and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium', 1),
(13, 'What is a Fault and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium', 1),
(14, 'Explain briefly about Joints and Unconformities.', 'ENGINEERING GEOLOGY', 3, 'easy', 1),
(15, 'Explain STRIKE, DIP, HADE, DIP AMOUNT, SLIP.', 'ENGINEERING GEOLOGY', 3, 'hard', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
