import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { ToasterModule, ToasterService, ToasterConfig } from 'angular2-toaster';
@Component({
  selector: 'app-questionslist',
  templateUrl: './questionslist.component.html',
  styleUrls: ['./questionslist.component.css']
})
export class QuestionslistComponent implements OnInit {
  private toasterService: ToasterService;
  public toasterconfig : ToasterConfig = 
      new ToasterConfig({timeout: 1000});
  msg: boolean;
  model: any;
  data: any[];
  allUsers: any[];
  constructor(private service: ApiService, public router: Router, toasterService: ToasterService) { }
  quelist = [];
  ngOnInit() {
    this.service.getmcqquestions().subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });
  }
  quesentry() {
    this.router.navigate(['quesentry']);
  }

  send(value) {
    console.log(value);


  }
  click(value) {
    console.log(value);
    this.service.finalque(value).subscribe(ques => {
      //s console.log(ques);

    });
  }
  popToast() {
    this.toasterService.pop('success', 'Password updated Successfully');
  }


  qid;
  deleteTicket() {
    console.log(this.qid);

    this.service.deleteTicket(this.qid).subscribe(del => {
      if (del) {
        this.qid = '';
        //window.rel
        location.reload();
      }
    })
  }

}
