import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { OnInit,EventEmitter,Output,Input} from '@angular/core';

@Injectable()
export class TicketsdataService {
     tabledata=[];
     tabledata1:any;
 // @Input('value') value: TicketsdataService;
  constructor(private api:ApiService) {
    this.api.getAllTickets().subscribe(data=>{
       this.tabledata.push(data);
       console.log('ygdgdgdgdgd',this.tabledata);
     /// this.tabledata1=this.tabledata;
    })
   }
   
}
