import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule, Form, FormGroup, FormBuilder, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes, Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { AppComponent } from './app.component';
import { ApiService } from './api.service';
//import { LdateComponent } from './common/ldate.component';
//import {JsonfilterPipe} from './jsonfilter.pipe';
import { ValuesPipe } from './values.pipe';
import { AuthGuard } from './authentication';
import { HeaderComponent } from './header/header.component';
import { LeftnavComponent } from './leftnav/leftnav.component';
//import {columnPipe,rowPipe,searchPipe} from  './searchpipe';
//import {Ng2SearchTableModule} from "ng2-search-table/ng2-search-table";
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { HotTableModule } from 'ng2-handsontable';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { Ng2TableModule } from 'ng2-table/ng2-table';
import { SelectModule } from 'ng-select';
import { FooterComponent } from './footer/footer.component';
import { DataTableModule } from "angular2-datatable";
import { DataFilterPipe } from './datatable-filter';
import { CKEditorModule } from 'ng2-ckeditor';
import { ExportService } from './common/export.service';
import { Pipe, PipeTransform } from '@angular/core';
import { UniquePipe } from "../uniquepipe";
import { QuesentryComponent } from './quesentry/quesentry.component';
import { QuestionslistComponent } from './questionslist/questionslist.component';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { ListComponent } from './list/list.component';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';const approutes: Routes = [

   {path:'',component:DashboardComponent},
   { path: 'dashboard', component: DashboardComponent },
    {path:'dashboard/:livePage',component:DashboardComponent},
  { path: '', component: QuesentryComponent },
    { path: '', component: QuestionslistComponent },
   { path: 'quesentry', component: QuesentryComponent },
       { path: '', component:  ListComponent },
   { path: 'quesentry', component: ListComponent },
  { path: 'queslist', component: QuestionslistComponent },
  // {path:'dashboard',component:DashboardComponent, canActivate:[AuthGuard]},
  //  {path:'home',component:HomeComponent, canActivate:[AuthGuard]},
  //  {path:'dashboard/:livePage',component:DashboardComponent, canActivate:[AuthGuard]}

]

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
 
    ValuesPipe,
    UniquePipe,
    HeaderComponent,
    LeftnavComponent,



    FooterComponent,
    DataFilterPipe,
    QuesentryComponent,
    QuestionslistComponent,
    ListComponent,





  ],

  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(approutes),
    ReactiveFormsModule,
    Ng2SmartTableModule,
    HotTableModule,
    ToasterModule,
    Ng2TableModule,
    SelectModule,
    DataTableModule,
    CKEditorModule,
    AngularMultiSelectModule,


    //Ng2SearchTableModule

  ],

  providers: [
    ApiService,
    AuthGuard,
    ExportService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
