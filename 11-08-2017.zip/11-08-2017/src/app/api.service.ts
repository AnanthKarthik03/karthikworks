import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Rx';
 


@Injectable()
export class ApiService {
        headers      = new Headers({ 'Content-Type': 'application/json','Accept': 'application/json' }); // ... Set content type to JSON
        options = new RequestOptions({ headers: this.headers });
         livePage:string;
         role:any;
        public  activity = [
       
        { title: 'Project', value: 'project' },
        { title: 'Training', value: 'training' },
        { title: 'System Admin', value: 'system_admin' },
        { title: 'HR Corporate Maintenance', value: 'hr_corp maintain' },
        { title: 'Any Other', value: 'any_other' },
    ]

    public  timings = [
        
        { title: '9:00 AM', value: '9:00 AM' },
        { title: '9:15 AM', value: '9:15 AM' },
        { title: '9:30 AM', value: '9:30 AM' },
        { title: '9:45 AM', value: '9:45 AM' },
        { title: '10:00 AM', value: '10:00 AM' },
        { title: '10:30 AM ', value: '10:30 AM' },
        { title: '10:45 AM', value: '10:45 AM' },
        { title: '11:00 AM', value: '11:00 AM' },
        { title: '11:15 AM', value: '11:15 AM' },
        { title: '11:30 AM', value: '11:30 AM' },
        { title: '11:45 AM', value: '11:45 AM' },
        { title: '12:00 PM', value: '12:00 PM' },
        { title: '12:15 PM', value: '12:15 PM' },
        { title: '12:30 PM', value: '12:30 PM' },
        { title: '12:45 PM', value: '12:45 PM' },
        { title: '1:00 PM', value: '1:00 PM' },
        { title: '1:15 PM', value: '1:15 PM' },
        { title: '1:30 PM', value: '1:30 PM' },
        { title: '1:45 PM', value: '1:45 PM' },
        { title: '2:00 PM', value: '2:00 PM' },
        { title: '2:15 PM', value: '2:15 PM' },
        { title: '2:30 PM', value: '2:30 PM' },
        { title: '2:45 PM', value: '2:45 PM' },
        { title: '3:00 PM', value: '3:00 PM' },
        { title: '3:15 PM', value: '3:15 PM' },
        { title: '3:30 PM', value: '3:30 PM' },
        { title: '3:45 PM', value: '3:45 PM' },
        { title: '4:00 PM', value: '4:00 PM' },
        { title: '4:15 PM', value: '4:15 PM' },
        { title: '4:30 PM', value: '4:30 PM' },
        { title: '4:45 PM', value: '4:45 PM' },
        { title: '5:00 PM', value: '5:00 PM' },
        { title: '5:15 PM', value: '5:15 PM' },
        { title: '5:30 PM', value: '5:30 PM' },
        { title: '6:00 PM', value: '6:00 PM' },
         
    ]
  constructor(private http:Http) { }

addUsers (body: any) {
        let bodyString = JSON.stringify(body); // Stringify payload
         console.log(bodyString);
        return this.http.post('http://210.16.79.137/live/myworks/api/addUsers', bodyString, this.options) // ...using post request
                         .map((res:Response) => res.json()) // ...and calling .json() on the response to return data    
    }
getUsers(id:any,role:any){
    console.log(id);
    
        let bodyString = JSON.stringify({'user_id':id,'role':role});
       
        return this.http.post('http://210.16.79.137/live/myworks/api/getUsers',bodyString,this.options)
                         .map((res:Response) => res.json())
} 
loginCheck(body:any){
    let bodyString = JSON.stringify(body); // Stringify payload
        console.log(bodyString);
        return this.http.post('http://210.16.79.137/live/myworks/api/loginCheck', bodyString, this.options)  
                         .map((res:Response) => res.json());    

}

addTicket(body:any){
    let bodyString=JSON.stringify(body);
    return this.http.post('http://210.16.79.137/live/myworks/api/addTicket', bodyString, this.options)  
                         .map((res:Response) => res.json());    
}
changePassword(body:any){
    let bodyString=JSON.stringify(body);
    return this.http.post('http://210.16.79.137/live/myworks/api/changePassword', bodyString, this.options)  
                         .map((res:Response) => res.json());    
}
updateTicket(body:any){
    let bodyString=JSON.stringify(body);
    console.log(bodyString);
    return this.http.post('http://210.16.79.137/live/myworks/api/updateTicket', bodyString, this.options)
                         .map((res:Response) => res.json());  
}
getTickets(id:any){
     let bodyString=JSON.stringify({'id':id});
     return this.http.post('http://210.16.79.137/live/myworks/api/getTickets',bodyString,this.options)  
                         .map((res:Response) => res.json());
} 
getTicketsByCategory(id:any){
     let bodyString=JSON.stringify({'id':id});
     console.log(bodyString);
     return this.http.post('http://127.0.0.1/myworks/api/getTicketsByCategory',bodyString,this.options)  
                         .map((res:Response) => res.json())
}

 myDailyWork(body) {
     console.log(JSON.stringify(body));
     
        return this.http.post('http://127.0.0.1/myworks/api/get_daily_work',JSON.stringify(body),this.options)  
                         .map((res:Response) => res.json());    
    }


 getLectures(body) {
            return this.http.post('http://127.0.0.1/myworks/api/get_daily_work',JSON.stringify(body),this.options) 
                         .map((res:Response) => res.json())

        // return this._http.post(AppSettings.getLectureApi,
        //     {
        //         token: sessionStorage.getItem('currentUser'),
        //         reg_no: sessionStorage.getItem('reg_no')

        //     },
        //     this.options)
        //     .map(this.extractData)
        //     .catch(this.handleError);
    }

savemcqquestions(body){
                              console.log(body);

  return this.http.post('http://127.0.0.1/myworks/api/savemcqquestions',JSON.stringify(body),this.options) 
                         .map((res:Response) => res.json())

}
                        finalque(body){
  return this.http.post('http://127.0.0.1/myworks/api/finalque',JSON.stringify(body),this.options) 
                         .map((res:Response) => res.json())
                        }
 savemcqquestions1(body){
  return this.http.post('http://127.0.0.1/myworks/api/savemcqquestions1',JSON.stringify(body),this.options) 
                         .map((res:Response) => res.json())
}
                        getmcqquestions(){
                           
   return this.http.get('http://127.0.0.1/myworks/api/getmcqquestions',this.options).map((res:Response) => res.json())
}

getmcqquestionslist(){
                           
   return this.http.get('http://127.0.0.1/myworks/api/getmcqquestionslist',this.options).map((res:Response) => res.json())
}
getmcqquestionslist1(){
                           
   return this.http.get('http://127.0.0.1/myworks/api/getmcqquestionslist1',this.options).map((res:Response) => res.json())
}
getmcqquestionslist2(){
                           
   return this.http.get('http://127.0.0.1/myworks/api/getmcqquestionslist2',this.options).map((res:Response) => res.json())
}

    private extractData(response: Response) {
        const body = response.json();
        return body || {};
    }

    private handleError(error: Response): Observable<any> {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }

    getAllTickets(){
                console.log('getAllTickets');

        return this.http.get('http://127.0.0.1/myworks/api/getAllTickets',this.options).map((res:Response) => res.json())
    
}
    getAllTicketslead(id){
        let bodyString=JSON.stringify({'user_id':id});
        return this.http.post('http://127.0.0.1/myworks/api/getAllTicketslead',bodyString, this.options).map((res:Response) => res.json())
    }

    getTicketsbyMonth(id:any){
        console.log('getTicketsbyMonth',id);
        
       let bodyString=JSON.stringify({'id':id});
       return this.http.post('http://127.0.0.1/myworks/api/getTicketsbyMonth',bodyString,this.options).map((res:Response) => res.json())
    }

     getTicketsbyDay(id:any){
        console.log('getTicketsbyDay',id);
        
       let bodyString=JSON.stringify({'id':id});
       return this.http.post('http://127.0.0.1/myworks/api/getTicketsbyDay',bodyString,this.options).map((res:Response) => res.json())
    }
        
    getTicketsbyWeek(id:any){
        console.log('getTicketsbyweek',id);
        
       let bodyString=JSON.stringify({'id':id});
       return this.http.post('http://127.0.0.1/myworks/api/getTicketsbyWeek',bodyString,this.options).map((res:Response) => res.json());
    }

    deleteTicket(qid:any){
        let bodyString=JSON.stringify({'qid':qid});
        return this.http.post('http://127.0.0.1/myworks/api/deleteTicket',bodyString,this.options).map((res:Response) => res.json());
    }

    getTktsByType(type:string,id){
        let bodyString=JSON.stringify({'status':type,'user_id':id});
        console.log(bodyString);
        
        return this.http.post('http://127.0.0.1/myworks/api/getTktsByType',bodyString,this.options).map((res:Response)=>res.json());
    }
    myDailyWorkUpdate(value:any){
       // let bodyString=JSON.stringify(value);
        //console.log(bodyString);
        let bodyString=JSON.stringify({'lecture_id':value});
        return this.http.post('http://127.0.0.1/myworks/api/myDailyWorkUpdate',bodyString,this.options).map((res:Response)=>res.json());

    }

    deleteDailywork(id:any){
        let bodyString=JSON.stringify({'id':id});
        return this.http.post('http://127.0.0.1/myworks/api/deleteDailywork',bodyString,this.options).map((res:Response) => res.json());
    }

     getTktsByType_mwd(type:string,type1:string,id){
         console.log(type,type1);
        let bodyString=JSON.stringify({'status':type,'user_id':id,'type_tkts':type1});
        console.log(bodyString);
        
        return this.http.post('http://127.0.0.1/myworks/api/getTktsByType_mwd',bodyString,this.options).map((res:Response)=>res.json());
    }

    getTeamTktsbyId(value){
        console.log(value);
        
       let bodyString=JSON.stringify(value);
       return this.http.post('http://127.0.0.1/myworks/api/getTeamTktsbyId',bodyString,this.options).map((res:Response) => res.json());

    }

    notificationTkts(id:any){

        let bodyString=JSON.stringify({'user_id':id});
        return this.http.post('http://127.0.0.1/myworks/api/notificationTkts',bodyString,this.options).map((res:Response)=>res.json());
    }
    notificationReset(id:any){
      let bodyString=JSON.stringify({'user_id':id});
      return this.http.post('http://127.0.0.1/myworks/api/notificationReset',bodyString,this.options).map((res:Response)=>res.json());
  
    }
    getUserprofile(id:any){
        let bodyString=JSON.stringify({'id':id});
      return this.http.post('http://127.0.0.1/myworks/api/getUserprofile',bodyString,this.options).map((res:Response)=>res.json());
  
    }

    
getTicketsdemo(id){
        let bodyString=JSON.stringify({'user_id':id});
     return this.http.post('http://127.0.0.1/myworks/api/getTicketsdemo',bodyString,this.options)  
                         .map((res:Response) => res.json());
} 

updateTicket1(body:any){
    let bodyString=JSON.stringify(body);
    console.log(bodyString);
    return this.http.post('http://127.0.0.1/myworks/api/updateTicket1', bodyString, this.options)
                         .map((res:Response) => res.json());  
}
}

