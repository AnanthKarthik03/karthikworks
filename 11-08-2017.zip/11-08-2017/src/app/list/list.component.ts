import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { ExportService } from '../common/export.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  selectedItems2(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  dropdownSettings: { singleSelection: boolean; text: string; selectAllText: string; unSelectAllText: string; enableSearchFilter: boolean; classes: string; };
  selectedItems: { "id": number; "itemName": string; }[];
  dropdownList: { "id": number; "itemName": string; }[];
  alluers: any;
  allusers: any;
  data: Array<any>;
  msg: boolean;
  model: any;
  allUsers: any[];
  constructor(private service: ApiService, public router: Router, private _exportService: ExportService) { }
  quelist = [];
  quelist1 = [];
  quelist2 = [];
  ngOnInit() {
    this.service.getmcqquestionslist().subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });

    this.service.getmcqquestionslist1().subscribe(ques => {
      console.log(ques);
      this.quelist1 = ques;
    });

    this.service.getmcqquestionslist2().subscribe(ques => {
      console.log(ques);
      this.quelist2 = ques;
    });


    this.dropdownList = [
      { "id": 1, "itemName": "India" },
      { "id": 2, "itemName": "Singapore" },
      { "id": 3, "itemName": "Australia" },
      { "id": 4, "itemName": "Canada" },
      { "id": 5, "itemName": "South Korea" },
      { "id": 6, "itemName": "Germany" },
      { "id": 7, "itemName": "France" },
      { "id": 8, "itemName": "Russia" },
      { "id": 9, "itemName": "Italy" },
      { "id": 10, "itemName": "Sweden" }
    ];
    this.selectedItems = [
      { "id": 2, "itemName": "Singapore" },
      { "id": 3, "itemName": "Australia" },
      { "id": 4, "itemName": "Canada" },
      { "id": 5, "itemName": "South Korea" }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      text: "Select Countries",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems2);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems2);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }
  myForm = new FormGroup({
    course: new FormControl()


  });


  quesentry() {
    this.router.navigate(['quesentry']);
  }

  send(value) {
    console.log(value);

  }

  qid;
  deleteTicket() {
    console.log(this.qid);

    this.service.deleteTicket(this.qid).subscribe(del => {
      if (del) {
        this.qid = '';
        //window.rel
        location.reload();
      }
    })
  }

  refresh() {
    location.reload();
  }

  print(): void {
    let printContents, popupWin;
    printContents = document.getElementById('print-section').innerHTML;
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
          <title>Question paper
          </title>
         
          <style>
          //........Customized style.......
          </style>
        </head>
    <body onload="window.print();window.close()">${printContents}</body>
      </html>`
    );
    popupWin.document.close();
  }









}
