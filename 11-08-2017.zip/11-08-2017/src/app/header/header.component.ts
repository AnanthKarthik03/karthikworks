import { Component, OnInit,EventEmitter,Output,Input } from '@angular/core';
import {Router} from '@angular/router';
import {ApiService} from '../api.service';
 
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Output() selectedpage=new EventEmitter();
  user_id=localStorage.getItem('user_id');
  name= localStorage.getItem('name');
   
  noifications;
  constructor(private router:Router,public api:ApiService) { }

  ngOnInit() {
    this.notificationTkts();
    
                
  }
logout(){
  localStorage.removeItem('name');
  localStorage.removeItem('user_id');
  localStorage.removeItem('reg_no');
  localStorage.removeItem('role');
  this.router.navigate(['']);
}
notificationTkts(){
  this.api.notificationTkts(this.user_id).subscribe(data=>{
    if(data){
      console.log(data[0].notifications);
      this.noifications=data[0].notifications;
      
      }else{
        console.log('no data found');
        
      }
  })
}

mytickets(){
  this.api.notificationReset(this.user_id).subscribe(data=>{
    if(data){
      // console.log(data[0].notifications);
      // this.noifications=data[0].notifications;
     
      
      }else{
        console.log('no data found');
        
      }
  })
  //location.reload();
  this.router.navigate(['dashboard/mytickets']);
   this.notificationTkts();
  
}
sidebarchage(type:string){
  this.api.livePage=type;
//this.selectedpage.emit(type);
}
}
