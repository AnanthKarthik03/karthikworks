import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute} from '@angular/router';
import { ApiService } from '../api.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
role=localStorage.getItem('role');
  constructor(public router:Router,public api:ApiService,private activeR:ActivatedRoute) { }

  ngOnInit() {
        this.activeR.params.subscribe(params=>{
      this.api.livePage=params['livePage'];
      console.log(params['livePage']);
      console.log(this.api.livePage);
      
    })
  }

sidebarchage(type:string){
  this.api.livePage=type;
  this.router.navigate(['/dashboard/'+type]);
  console.log("page is:"+type);
  
//this.page_name=type;
}
}
