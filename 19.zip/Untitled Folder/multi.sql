-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2017 at 02:16 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `multi`
--

CREATE TABLE `multi` (
  `sid` int(11) NOT NULL,
  `question` varchar(500) NOT NULL,
  `op1` varchar(100) NOT NULL,
  `op2` varchar(100) NOT NULL,
  `op3` varchar(100) NOT NULL,
  `op4` varchar(100) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `answer` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `multi`
--

INSERT INTO `multi` (`sid`, `question`, `op1`, `op2`, `op3`, `op4`, `unit`, `answer`) VALUES
(132, 'APJ Abdul Kalam was born in the year?', '1929', '1930', '1931', '1932', '1', '1931'),
(133, 'What is the anytonym of the word \'frugal\'.', 'regal', 'economical', 'economic', 'spendthrift', '1', 'spendthrift'),
(134, 'Srinivasa Ramanujan was born in the year?', '1887', '1885', '1895', '1878', '1', '1887'),
(135, 'Describe the job done by an architect from the following:', 'Buys and sells or barters', 'lays water and sewage pipelines', 'cares for the sick', 'Designs buildings and advises in their construction', '1', 'Designs buildings and advises in their construction'),
(136, 'Dr. Vijay P Bhatkar is one of the initiators of the electronics revolution in India and an......... (Acclaim) global leader in computing.', 'Acclaimed', 'acclaims', 'acclaim', 'was acclaimed', '1', 'Acclaimed'),
(137, 'Give Synonym for the word Appalling:', 'Enjoying', 'charming', 'cheerful', 'horrifying', '1', 'horrifying'),
(138, 'Where did (1)/ you (2)/ went (3)/yesterday? (4).Identify the part of sentence which has an error.', '1', '2', '3', '4', '1', '3'),
(139, 'Give Synonym for the word gleaned:', 'separated', 'acted', 'collected', 'granted', '1', 'collected'),
(140, 'A person who moves from one place to another for a limited period.(one word substitution) :', 'Migrant', 'stoic', 'aboriginal', 'primitive', '1', 'Migrant'),
(141, 'A person having an instinctive and extraordinary capacity for creative activity.(one word substitution) ', 'creator', 'intelligent', 'genius', 'amateur', '1', 'genius'),
(142, 'Describe the job done by a plumber from the following:', 'Uses brick and mortar and builds houses', 'Lays water and sewage pipelines', 'Cultivates land and raises food crops.', 'A person who works in a branch of science', '1', 'Lays water and sewage pipelines'),
(143, 'If we finish our work in time, we\'ll go for a movie.(choose the correct substitution for the bold word).', 'If we finished', 'if we will finish', 'if we would finish', 'No improvement', '1', 'No improvement'),
(144, 'Find out the word with correct spelling.', 'Milennium', 'Millenium', 'Millennium', 'Milenium', '1', 'Millennium'),
(145, 'Find out the word with correct spelling.', 'Gaurantee', 'Guarantee', 'Garuntee', 'Guaruntee', '1', 'Guarantee'),
(146, 'Find out the word with correct spelling.', 'Rasteraunt', 'Restaurent', 'Rastaurent', 'Restaurant', '1', 'Restaurant'),
(147, 'What is the name of the Chairman of the office in which Ramanujan worked?', 'Sir Ferdinand De Saussure ', 'Sir Flamingo', 'Sir Friar', 'Sir Francis Spring', '1', 'Sir Francis Spring'),
(148, 'An animal story with a moral.(one word substitution) ', 'Fable', 'Tale', 'Anecdote', 'Parable', '2', 'Fable'),
(149, 'One who is interested in the welfare of women.(one word substitution) ', 'Feminine', 'Feminist', 'Effeminate', 'Flamboyant', '2', 'Feminist'),
(150, 'Give Antonym for the word uncanny:', 'Ordinary', 'mysterious', 'prodigious', 'scary', '2', 'Ordinary'),
(151, 'Give Antonym for the word jaunty:', 'Happy', 'sprightly', 'serious', 'cheerful', '2', 'serious'),
(152, 'What is the synonym of the word ‘Congestion’?', 'Overcrowding of people or vehicles ', 'Contraction', 'Expansion', 'Maldigestion', '2', 'Overcrowding of people or vehicles '),
(153, 'If the prefix TRANS means ‘ACROSS’, what is the meaning of the word TRANSCRIBE?', 'Put thoughts, ideas or speech into written or printed form', 'Cut across something', 'Move across from one point to the other', 'To violate a rule or law', '2', 'Put thoughts, ideas or speech into written or printed form'),
(154, 'The drivers indulging in overspeeding or rash and reckless driving should be heavily _______. (Fill in the blank with the most appropriate word from the given choices)', 'Punished ', 'Penalized', 'Reprimanded ', 'Warned ', '2', 'Penalized'),
(155, 'How would you solve the problem of traffic jams and avert accidents near a school zone? (Choose the most logical answer from the given options) ', 'Build flyovers to divert heavy traffic ', 'Construct speed-breakers to check overspeeding', 'Declare the precincts of the school as no-traffic zone', 'Both a,b', '2', 'Both a,b'),
(156, 'People who are in a desperate hurry to reach their destinations are at the mercy of unscrupulous auto and taxi drivers who dictate terms to them.\nWhat is the meaning of the word ‘Unscrupulous’ in the above sentence? Select one from the options below.\n', 'Unethical ', 'Ruthless', 'Deviant ', 'Shameless', '2', 'Unethical '),
(157, 'The potential capacity of the skybus is one lakh passenger per hour.\nWhat is the meaning of the word ‘Potential’ in the above sentence? Select the appropriate option.\n', 'Showing the capacity to develop into something productive in the near future. ', 'Strong and sturdy ', 'Accommodating more number of passengers', 'The quantity determining the energy of a mass in a gravitational field', '2', 'Showing the capacity to develop into something productive in the near future. '),
(158, 'According to the information given in the passage “Road Safety: a Public Health Issue’ what is the number of people killed in road accidents in the year 1996? ', '1.2 million', '2.1 million', '1.5 million', '1.25 million', '2', '1.2 million'),
(159, 'A wide range of effective _________ have to be strategically devised to regulate the hazards of motorized travel in today’s world. (Fill in the blank with the appropriate word from the given options)', 'Interceptions', 'Interventions', 'Intermissions', 'Interrogations', '2', 'Interventions'),
(160, 'Which of the following sentences is grammatically most appropriate?', 'The immediate need of the hour is to create greater traffic awareness among the civilians and educat', 'The immediate need of the hour is creating greater traffic awareness among the civilians and educate', 'The immediate need of the hour is greatly creating traffic awareness among the civilians and on educ', 'None of the above ', '2', 'The immediate need of the hour is to create greater traffic awareness among the civilians and educat'),
(161, 'Once you are in the bus starts the hide and seek with the conductor who is always seen playing hard to get. What is the meaning of the idiom “play hard to get” from the above sentence? ', 'Playing a game in a sportive fashion', 'To pretend that you are less interested in someone than you really are', 'Not giving any chance to the opponent in a game', 'Escaping one’s attention by hiding', '2', 'To pretend that you are less interested in someone than you really are'),
(162, 'The Ministry of Transport should provide the following facilities to the public in order to tackle the illegitimate private transport practices in the country. (Choose all logically possible options which can best support the above statement). ', 'Arrange special cells for speedy redressal of public grievances. ', 'Conduct surprise checks on the drivers and put them through Breath Alcohol Test.', 'Make regulations for the installation of Government authorised electronic metres in auto rickshaws. ', 'Crack down heavily on public transport authorities and drivers for violating traffic and road safety', '2', 'A)Arrange special cells for speedy redressal of public grievances. ,B)Conduct surprise checks on the'),
(163, 'What is the meaning of the word ‘Coroner’? Choose the most appropriate option.', 'King Maker', 'A traffic police constable', 'A public officer appointed by the government who legally probes into the cause of unnatural deaths.', 'Said of the man who heads the ceremony of crowing a King or Monarach.', '2', 'A traffic police constable'),
(164, 'Wriggling through the vast mass of humanity to find your way through. What is the meaning of the word ‘Wriggling’ in the above sentence. Choose the word closest in meaning from the given options.', 'To move along by twisting and turning the body', 'Moving through a tunnel', 'To cause pain to humanity to reach your goal', 'Fight with people to make your way through a difficult situation.', '2', 'To move along by twisting and turning the body'),
(165, 'Which of the following is not the meaning of the word \'cutting edge\'?UNIT-2)', 'Pioneer', 'Advancement', 'Conventional ', 'Innovative', '2', 'Conventional '),
(166, 'Which of the following is one of the most widely used US employment visa?UNIT-1)', 'B-1', 'L-1', 'TN', 'H1-B', '2', 'H1-B'),
(167, 'The US Government has proposed to increase the number of H1-B visas by how many per year?UNIT-1)', '1,05,000', '95000', '90000', '1,95,000', '2', '95000'),
(168, 'Ramanujan\'s mathematical findings could be used in which of the following?', 'Boolean Alzebra', 'Vedic Maths ', 'String Theory', 'Euler\'s Theorems', '2', 'String Theory'),
(169, 'When did Ramanujan write to GH Hardy?', '16 Jun 13', '16 Jun 14', '16 Jun 03', '16 Jun 09', '2', '16/06/13'),
(170, 'The Visa Category \'E\' covers which of the following immigrants?', 'Treaty Traders', 'Entrepreneurs', 'Innovators', 'Software Professional', '2', 'Treaty Traders'),
(171, 'How many eligibility requirements need to be fulfilled to acquire an H1-B visa?', '5', '6', '7', '8', '2', '5'),
(172, 'The community type hybride solar cooker consists of a _____ with steel tray inside.', 'metallic box', 'copper box', 'wooden box', 'silver box', '2', 'wooden box'),
(173, 'In a hybrid solar cooker, the ______ paint as well as the insulation prevent the heat from escaping.UNIT-3)', 'red ', 'black', 'bluish red', 'gray', '2', 'black'),
(174, 'The place, where former President of India Dr A. P. J. Abdul Kalam was born?', 'Rameswaram', 'Hyderabad ', 'Kottayam', 'Madras (Chennai)', '2', 'Rameswaram'),
(175, 'Former President of India Dr A. P. J. Abdul Kalam had worked with which of following organizations?', 'Defence Research and Development Organisation (DRDO)', 'Indian Space Research Organisation (ISRO)', 'A and b both', 'Neither a nor b', '2', 'A and b both'),
(176, 'Dr A. P. J. Abdul Kalam is known as:', ' Missile Man of India', 'Iron Man of India', 'Only A', 'Both A and B', '2', 'Only A'),
(177, 'Dr A. P. J. Abdul Kalam was honoured with India’s highest civilian honour- Bharat Ratna in-', '2001', '1999', '1997', '2015', '2', '1997'),
(178, 'Dr A. P. J. Abdul Kalam became President of India in:', '2001', '2002', '2000', '2003', '2', '2002'),
(179, 'Dr A. P. J. Abdul Kalam had not worked in one of the following positions:', 'Chief Scientific Adviser to the Prime Minister', 'Secretary of the Defence Research and Development Organisation (DRDO)', 'Project director of India’s first Satellite Launch Vehicle (SLV-III)', 'Secretary of the Ministry of Defence', '2', 'Secretary of the Ministry of Defence'),
(180, 'As the 11th President of India, Dr A. P. J. Abdul Kalam succeeded:', 'K. R. Narayanan', 'R. Venkatraman', 'Dr. Shankar Dayal Sharma', 'Pratibha Patil', '2', 'K. R. Narayanan'),
(181, 'The place, where former President of India Dr A. P. J. Abdul Kalam died:', 'Shillong', 'Mumbai', 'Guwahati', ' Kolkata', '2', 'Shillong'),
(182, 'Former President of India Dr A. P. J. Abdul Kalam died on', '24 Jul 15', '25 Jul 15', '26 Jul 15', '27 Jul 15', '2', '27/07/15'),
(183, 'Which one of following statements on Dr A. P. J. Abdul Kalam is Not Correct', 'He was 11th president of the Republic of India', 'He was against of Uniform Civil Code in India', 'He was the third President of India to have been honoured with a Bharat Ratna, India’s highest civil', 'He was also the first scientist and the first bachelor to occupy Rashtrapati Bhawan', '2', 'He was against of Uniform Civil Code in India'),
(184, 'Kalam\'s 79th Birthday was recognized as ________ by the United Nations.', 'World Student Day', 'World Science Day', 'International Scientist Day', 'World Scientist Day', '2', 'World Student Day'),
(185, 'Kalam-Raju stent is a ', 'Technology developed for Ballistic missiles by Dr. APJ Abdul Kalam', 'Tablet-PC developed by Dr. APJ Abdul Kalam', 'Technology developed by Kalam to treat patients with heart ailments. ', '', '2', 'CTechnology developed by Kalam to treat patients with heart ailments. '),
(186, '\"Light from many lamps\", a book that finfluenced APJ Abdul Kalam, was written by', 'Lilian Eichler Watson', 'Dr. Vikram Sarabhai', 'Alexis Carrel', 'William Butler Yeats. ', '2', 'Dr. Vikram Sarabhai'),
(187, '\"This was my first stage, in which I learnt leadership from three great teachers.\" Who among the following was not one of the three?', 'Dr. Vikram Sarabhai', 'Prof. Satish Dhawan', 'Dr. Brahm Prakash', 'Raja Ramanna', '2', 'Raja Ramanna'),
(188, 'The lecture Kalam was delivering on the day of his demise at an IIM was?', 'The Livable Planet Earth', 'Vision 2020', 'India of my Dreams', 'Reignited', '2', 'The Livable Planet Earth'),
(189, 'Which of the following is Kalam\'s Autobiographical work?', 'India 2020', 'Wings of Fire ', 'Turning Points ', 'Pride of the Nation ', '2', 'Wings of Fire '),
(190, 'Who is the director of the movie \'I am Kalam\'?', 'Rajkumar Hirani', 'Nila Madhab Panda', 'Farah Khan', ' Kabir Khan', '2', 'Nila Madhab Panda'),
(191, 'In which Year PM  Indira Gandhi visited Thumba ?', '1967', '1968', '1969', '1970', '3', '1969'),
(192, 'In TERLS  acronym \" R\" stands for ?', 'Regional', 'Rameswaram', 'Rocket', 'Research', '3', 'Rocket'),
(193, 'Why did Prof.Sarabhai decide to launch satellite from Sriharikota?', 'to maximise the advantage of launch', 'to incur more cost', 'to get more wisdom', 'to get good  labour', '3', 'to maximise the advantage of launch'),
(194, 'When was Indian Rocket Society had formed ?', '1967', '1968', '1966', '1969', '3', '1968'),
(195, 'Name the French visitor brought by Prof.Sarabhai to SHAR?', 'Mr Murthy', 'Dr.Curien', 'Kurup', 'Satyanarayana', '3', 'Dr.Curien'),
(196, 'Kalam failed to get admission into which Indian Defence Course ?', 'IAF', 'ICS', 'IIT', 'Indian Fine Arts', '3', 'IAF'),
(197, 'Which two famous  scientists helped Kalam in his SLV-3  project.', 'Ali Jinna  and  Sethuraman', 'Palani and Jinna', 'UR Rao and   M. Nair', 'Both A  and B', '3', 'Both A  and B'),
(198, 'What is  RATO  stands for ?', 'Road And Traffic Office', 'Rytu and Toll Office', 'Rocket and Tell Off', 'Rocket-assisted take -off system', '3', 'Rocket-assisted take -off system'),
(199, 'What is the meaning of inevitable ?', 'that is expected to happen surely', 'known nothing', 'abounds every area', 'not known ', '3', 'that is expected to happen surely'),
(200, 'Who was the project Director of  PSLV ?', 'Mahatma Gandhi', 'Shri Ambedkar', 'Madhavan Nair', 'Tambidurai', '3', 'Madhavan Nair'),
(201, 'Which great Professor helped author in realising mistakes in VSSC ?', 'Prof.Sarabhai', 'Prof.Einestein', 'Prof.Edison', 'M K Ghandhi', '3', 'Prof.Sarabhai'),
(202, 'When did Prof. Sarabhai pass away ?', '12 Jun 70', '30 Dec 69', '30 Dec 71', '30 Dec 80', '3', '30/12/71'),
(203, 'Who is considered the Mahatma of Indian Science by Kalam ?', 'Prof.Murthy', 'Prof. Willims', 'Prof. Sarabhai', 'Prof.Narayanan', '3', 'Prof. Sarabhai'),
(204, 'Name the  rocket  tested on 8th October 1972 at Bareilly Air Station?  GSLV 2', 'PSLV11177', 'PSLV11166', 'Sukhoi-16', 'INSAT   F ROCKET', '3', 'Sukhoi-16'),
(205, 'What was the short run of Sukhoi-16   in  space  when it stationed?', '1000  m', '1200 m', '1300 m', '1400 m', '3', '1200 m'),
(206, 'In VSSC  whatt does  \'V\"   stand  for ?', 'Vikram', 'Vaibhai jewellers', 'Vaibhavam', 'Vernacular', '3', 'Vikram'),
(207, 'Who was appoined  as  Project Manager - to  SLV?', 'Prof.Murthy', 'Prof  U thant', 'Prof  Jenny', 'Prof APJ  Abdul Kalam', '3', 'vProf APJ  Abdul Kalam'),
(208, 'Who formed Project Advisory Committees under great scientists ?', 'Prof.  Alok Malhotra', 'Prof.Sangh Mitra', 'Dr.Brahm Prakash', 'Dr.Jeevam', '3', 'Dr.Brahm Prakash'),
(209, 'How many Engineers were expected by author for SLV-3  project?', '600', '275', '300', '100', '3', '275'),
(210, 'What is the key  element in the  success of  project works ?', 'Laziness ', 'Patience ', 'team work', 'disintegration', '3', 'team work'),
(211, 'According to the author what is the meaning of \"hands-on\"?', 'escaping from work', 'negative approach', 'Both A and B', 'active interest in team', '3', 'active interest in team'),
(212, 'How many sub-assemblies were conceived for SLV-3 ?', '111', '250', '150', '450', '3', '250'),
(213, 'which are mentioned as first cousins by the author ?', 'buckets and tubs', 'machines and gears', 'SLVs and missiles', 'brothers and sisters', '3', 'SLVs and missiles'),
(214, 'Who was the Director of   DRDL  ?', 'Mukesh Kumar Pandhya', 'Narayanan', 'Prof.Srinivasanan', ' Prof Kutty swamy', '3', 'Narayanan'),
(215, 'What is the meaning of \'dwindled \' ?', 'Increased', 'developed', 'progressed', 'Reduced', '3', 'Reduced'),
(216, 'While working with SLV-3 the author considered himself as ..?', 'an arrogant talker', 'a talkative', 'a pessimist', 'a good communicator', '3', 'a good communicator'),
(217, '\"Knowledge is a tangible asset….\" who said this  ?', 'Prof.Kalam', 'Prof.Narayanan', 'Prof .Balaram', 'Prof.Vikrama', '3', 'Prof.Kalam'),
(218, '\"Be active! Take on responsibility!Work for the things you believe in\"', 'Prof.Narayanan', 'Prof.Brahm Prakash', 'Dr.Jeevam', 'Prof.Kalam', '3', 'Prof.Kalam'),
(219, 'When did ISRO  became a government body  ?', '1969', '1974', '1975', '1976', '3', '1975'),
(220, 'When was the first orbital flight was commissioned by Indira Gandhi?', '1978', '1979', '1969', '1980', '3', '1978'),
(221, 'In which year father of Prof.Kalam  demised ?', '1975', '1976', '1977', '1980', '3', '1976'),
(222, 'What is the meaning of \" Evaluating\" ?', 'Choosing the best', 'searching', 'Reducing', 'less choice', '3', 'A'),
(223, 'What is the synonym of \'Cumulative\"  ?', 'decreasing', 'dwindling', 'lessing', 'increasing', '3', 'increasing'),
(224, 'Which one of the following is a conventional fuel  ?', 'Electricity', 'Solar energy', 'Latest Biomass', 'Coal', '3', 'Coal'),
(225, 'What is the benefit of modern Solar energy  ?', 'Reduces the income', 'Increases  cost', 'Both A and B', 'Frugal and economic', '3', 'Frugal and economic'),
(226, '\"Technology is  to be used for good of mankind\' ?Do you support?', 'Yes', 'No', 'No  but Yes', 'None', '3', 'Yes'),
(227, 'What is the meaning of \"disseminate\" ?', 'be angry with', 'discard', 'spread', 'stop', '3', 'spread'),
(228, 'Which is the non-renewable resource ?', 'wood', 'kerosene oil', 'solar energy', 'Solar heaters', '3', 'kerosene oil'),
(229, 'What is the chief advantage of Technology ?', 'increases hard work and burden', 'takes more time', 'consumes more power', 'reduces cost and economic', '3', 'reduces cost and economic'),
(230, 'What is the meaning of \'viable\' ?', 'Impossible', 'Possible', 'Both A and B', 'None of them', '3', 'Possible'),
(231, '\"Copy and Print Online\" is a  web-based service  provided by ?', 'Pins co.,', 'Staplers co.,', 'Staples', 'Micro-soft', '3', 'Staples'),
(232, '\"Fiery\" is the name of a  …..', 'unnatural- Machine', 'a Cinema box', 'a server', 'a super fast computer', '3', 'a server'),
(233, 'The biggest Global printing business exhibit  in 2006 in the world is-', 'EPEX', 'APEX', 'IPEX', 'ZPEX', '3', 'IPEX'),
(234, 'Digital Printers  are the ………', 'Latest  Printing machines', 'slow machine print', 'Off-set printing oldest', 'Both  C and D', '3', 'Latest  Printing machines'),
(235, 'What is the meaning of \'Indigenous\'  ?', 'Happening unnaturally', 'Occur naturally', 'Both A and B', 'None of them', '3', 'Occur naturally');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `multi`
--
ALTER TABLE `multi`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `multi`
--
ALTER TABLE `multi`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=238;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
