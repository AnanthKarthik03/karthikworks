import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
@Injectable()
export class ApiService {
    headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json' }); // ... Set content type to JSON
    options = new RequestOptions({ headers: this.headers });
    livePage: string;
    role: any;
    constructor(private http: Http) { }
    savemcqquestions(body) {
        console.log(body);

        return this.http.post('http://localhost/myworks/api/savemcqquestions', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())

    }
    saveinfo(body) {
        console.log(body);
        return this.http.post('http://localhost/myworks/api/saveinfo', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())
    }
    select(value) {
        console.log(value);
        return this.http.post('http://localhost/myworks/api/select', JSON.stringify(value), this.options)
            .map((res: Response) => res.json())
    }

    deselect(value) {
        console.log(value);
        return this.http.post('http://localhost/myworks/api/deselect', JSON.stringify(value), this.options)
            .map((res: Response) => res.json())
    }
    savemcqquestions1(body) {
        return this.http.post('http://localhost/myworks/api/savemcqquestions1', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())
    }
    getmcqquestions(obj) {
let bodyString = JSON.stringify(obj);
        return this.http.post('http://localhost/myworks/api/getmcqquestions',bodyString, this.options).map((res: Response) => res.json())
    }
    getsub(value) {
        console.log(value);
        let bodyString = JSON.stringify(value);
        return this.http.post('http://127.0.0.1/myworks/api/getsub', bodyString, this.options).map((res: Response) => res.json());
    }
    getmcqquestionslist(value) {
  let bodyString = JSON.stringify(value);
        return this.http.post('http://localhost/myworks/api/getmcqquestionslist', bodyString,this.options).map((res: Response) => res.json())
    }
    mcqlist(value) {
        let bodyString = JSON.stringify(value);
              return this.http.post('http://localhost/myworks/api/mcqlist', bodyString,this.options).map((res: Response) => res.json())
          }
    getmcqquestionslist1(value) {
  let bodyString = JSON.stringify(value);
        return this.http.post('http://localhost/myworks/api/getmcqquestionslist1',bodyString, this.options).map((res: Response) => res.json())
    }
    getmcqquestionslist2(value) {
  let bodyString = JSON.stringify(value);
        return this.http.post('http://localhost/myworks/api/getmcqquestionslist2', bodyString,this.options).map((res: Response) => res.json())
    }
    getinfo() {

        return this.http.get('http://localhost/myworks/api/getinfo', this.options).map((res: Response) => res.json())
    }
     getsubjectslist(val) {
let bodyString = JSON.stringify(val);
        return this.http.post('http://localhost/myworks/api/getsubjectslist',bodyString, this.options).map((res: Response) => res.json())
    }
}

