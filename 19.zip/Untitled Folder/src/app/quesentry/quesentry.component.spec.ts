import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuesentryComponent } from './quesentry.component';

describe('QuesentryComponent', () => {
  let component: QuesentryComponent;
  let fixture: ComponentFixture<QuesentryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuesentryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuesentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
