import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-quesentry',
  templateUrl: './quesentry.component.html',
  styleUrls: ['./quesentry.component.css']
})
export class QuesentryComponent implements OnInit {

   private _values4 = [];
  constructor(private service: ApiService, public router: Router) { }
  ngOnInit() {
    this.myForm.patchValue({
  year:1,
  sem:1,
  mid:1
});

   const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;
     
    });
  }

  firstDropDownChanged(val: any) {

    console.log(this.myForm.value,'my form test');
    


    const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;
     
    });
  
    console.log(val, obj);
 

    
  }
  
  myForm = new FormGroup({
    question: new FormControl(),
    subject: new FormControl(),
    setno: new FormControl(),
    level: new FormControl(),
   year: new FormControl(),
    sem: new FormControl(),

  });
  save(value) {
    console.log(value);
    this.service.savemcqquestions(value).subscribe(ques => {
    });
  }
  set(value) {
    console.log(value);
  }
  queslist() {
    this.router.navigate(['queslist']);
  }
  selstatus;
  statusChange($event) {
    this.selstatus = $event.srcElement.value;
  }
}