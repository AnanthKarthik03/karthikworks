import { Component, OnInit } from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { Router } from "@angular/router";


@Component({
  selector: 'app-rpq',
  templateUrl: './rpq.component.html',
  styleUrls: ['./rpq.component.css']
})
export class RpqComponent implements OnInit {
  ssname: string;
  options: DatePickerOptions;
   private _values4 = [];
 

  constructor(private service: ApiService, public router: Router) {
    this.options = new DatePickerOptions();

  }

  ngOnInit() {

this.myForm.patchValue({
  year:1,
  sem:1,
  mid:1
});
  const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;
     
    });
  }

  firstDropDownChanged(val: any) {

    console.log(this.myForm.value,'my form test');
    


    const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;
     
    });
  
    console.log(val, obj);
 

    
  }
  // date = this.date.formatted;
  myForm = new FormGroup({
    college: new FormControl(),
    dept: new FormControl(),
    // setno: new FormControl(),
    year: new FormControl(),
    mid: new FormControl(),
    sem: new FormControl(),
    subject: new FormControl(),
    date: new FormControl(),
    set: new FormControl(),
    


  });
  save(value) {
    console.log(value,this.ssname);
    // console.log(this.date.formatted);

    localStorage.setItem('college', value.college);
    localStorage.setItem('dept', value.dept);
    localStorage.setItem('year', value.year);
    localStorage.setItem('mid', value.mid);
    localStorage.setItem('sem', value.sem);
    localStorage.setItem('sub', value.subject);
    localStorage.setItem('date', value.date.formatted);
    localStorage.setItem('set', value.set);
    
    // this.service.saveinfo(value).subscribe(ques=>{
    //this.date.formatted;
    // console.log(ques);

    // });

  }

}
