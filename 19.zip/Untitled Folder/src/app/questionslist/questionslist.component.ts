import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-questionslist',
  templateUrl: './questionslist.component.html',
  styleUrls: ['./questionslist.component.css']
})
export class QuestionslistComponent implements OnInit {
  subject: any;
  msg: boolean;
  model: any;
  data: any[];
  allUsers: any[];
  constructor(private service: ApiService, public router: Router) { }
  quelist = [];
  ngOnInit() {
this.myForm.patchValue({
  year:1,
  sem:1,
  mid:1
});

   const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;

console.log(obj,'obj test');

      this.service.getmcqquestions(obj).subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });
    });


   
  }
  private _values1 = [
    { id: 1, val: "1" },
    { id: 2, val: "2" },
    { id: 3, val: "3" },
    { id: 4, val: "4" },
  ];
  private _values3 = [
    { id: 1, val: "1" },
    { id: 2, val: "2" },
  ];
  private _values2 = [];
  private _values4 = [];
  firstDropDownChanged(val: any) {

    console.log(this.myForm.value,'my form test');
    


    const obj = this.myForm.value;

    this.service.getsubjectslist(obj).subscribe(dat=>{
      console.log(dat);
      
      this._values4=dat;

    });
    // const obj2 = this._values3[val];
    console.log(val, obj);
  }
  myForm = new FormGroup
    ({
      year: new FormControl(),
      mid: new FormControl(),
      sem: new FormControl(),
      subject: new FormControl(),
    });
  quesentry() {
    this.router.navigate(['quesentry']);
  }
  getFullData(value) {
    this.myForm.value.sub = this.subject;
    console.log(this.myForm.value.subject);

      const obj = this.myForm.value;
     this.service.getmcqquestions(obj).subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });
  }
  click(value) {
    console.log(value);
    this.service.select(value).subscribe(ques => {
    });
  }
  declick(value) {
    console.log(value);
    this.service.deselect(value).subscribe(ques => {
    });
  }
}