import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { ExportService } from '../common/export.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare let jsPDF;
@Component({
  selector: 'app-multi',
  templateUrl: './multi.component.html',
  styleUrls: ['./multi.component.css']
})
export class MultiComponent implements OnInit  {
  showenable=false;
  keylist = new Object();
  sname: any;
  @ViewChild('test') el: ElementRef;

  selectedItems2(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  dropdownSettings: { singleSelection: boolean; text: string; selectAllText: string; unSelectAllText: string; enableSearchFilter: boolean; classes: string; };
  selectedItems: { "id": number; "itemName": string; }[];
  dropdownList: { "id": number; "itemName": string; }[];
  alluers: any;
  allusers: any;
  data: Array<any>;
  msg: boolean;
  model: any;
  allUsers: any[];

  constructor(private service: ApiService, public router: Router, private _exportService: ExportService) { }
  quelist = [];
  quelist1 = [];
  quelist2 = [];
  quelistinfo = {};
  a = {};
  ngOnInit() {
    const val = {
      year: localStorage.getItem('year'),
      sem: localStorage.getItem('sem'),
      sub: localStorage.getItem('sub'),
    }
    this.service.mcqlist(val).subscribe(ques => {
      console.log(ques);

      for (var i = 0; i < ques.length; i++) {
        var test=[];
        test.push(ques[i].op1);
         test.push(ques[i].op2);
          test.push(ques[i].op3);
           test.push(ques[i].op4);
             
           ques[i].op1=test[Math.floor(Math.random() * test.length)];
          
            var test2 = test.filter(function (obj) {
            return obj != ques[i].op1;
          });


           ques[i].op2=test2[Math.floor(Math.random() * test2.length)];

            test2 = test2.filter(function (obj) {
            return obj != ques[i].op2;
          });
         
           ques[i].op3=test2[Math.floor(Math.random() * test2.length)];

           test2 = test2.filter(function (obj) {
            return obj != ques[i].op3;
          });

           ques[i].op4=test2[0];
        
      }

      // var item = ques[Math.floor(Math.random()*ques.length)];
      // console.log(item,'rand');
      this.quelist = ques;
     
    });

 

    this.a['year'] = localStorage.getItem('year');
    this.a['sem'] = localStorage.getItem('sem');
    this.a['sub'] = localStorage.getItem('sub');
    this.a['mid'] = localStorage.getItem('mid');
    this.a['date'] = localStorage.getItem('date');
    this.a['dept'] = localStorage.getItem('dept');
    this.a['college'] = localStorage.getItem('college');
    this.a['sname'] = localStorage.getItem('sname');
    this.a['set'] = localStorage.getItem('set');
    






  }


  myForm = new FormGroup({
    course: new FormControl()


  });


  quesentry() {
    this.router.navigate(['quesentry']);
  }

  send(value) {
    console.log(value);

  }



  refresh() {
    // location.reload();
      const val = {
      year: localStorage.getItem('year'),
      sem: localStorage.getItem('sem'),
      sub: localStorage.getItem('sub'),
    }
    this.service.mcqlist(val).subscribe(ques => {
      console.log(ques);
       for (var i = 0; i < ques.length; i++) {
        var test=[];
        test.push(ques[i].op1);
         test.push(ques[i].op2);
          test.push(ques[i].op3);
           test.push(ques[i].op4);
             
           ques[i].op1=test[Math.floor(Math.random() * test.length)];
          
            var test2 = test.filter(function (obj) {
            return obj != ques[i].op1;
          });


           ques[i].op2=test2[Math.floor(Math.random() * test2.length)];

            test2 = test2.filter(function (obj) {
            return obj != ques[i].op2;
          });
         
           ques[i].op3=test2[Math.floor(Math.random() * test2.length)];

           test2 = test2.filter(function (obj) {
            return obj != ques[i].op3;
          });

           ques[i].op4=test2[0];
        
      }

      // var item = ques[Math.floor(Math.random()*ques.length)];
      // console.log(item,'rand');
      this.quelist = ques;
     
    });

  }
  
  printkey(){
  // this.keylist=new Object();
  //   for (var i = 0; i < this.quelist.length; i++) {
  
  //   this.keylist[i]=this.quelist[i].answer;
      
  //   }

    this.showenable=true
  
  
  }

  // print(): void {
  //   let printContents, popupWin;
  //   printContents = document.getElementById('print-section').innerHTML;
  //   popupWin = window.open('', '_blank', 'width=auto,height=100%,scrollbars=no,menubar=no,toolbar=no,location=no,status=no,titlebar=no');
  //   popupWin.document.open();
  //   popupWin.document.write(`
  //     <html>
  //      <style>
  //     #print-section {
  //         position:relative;
  //         left:0;
  //         top:0;
  //       }       
  //         </style>
  //   <body onload="window.print();window.close()">${printContents}</body>
  //     </html>`
  //   );
  //   popupWin.document.close();
  // }

  public download() {
    var doc = new jsPDF();
    doc.text(20, 20, 'Hello world!');
    doc.save('Test.pdf');
  }

  public pdfHtml() {
//    let pdf = new jsPDF();
//    const pdf = new jsPDF('p', 'pt', 'a4');
let pdf = new jsPDF('p', 'mm', [210, 297]);
    
    // let options = {
    //     pagesplit: true
    // };
    pdf.addHTML(this.el.nativeElement, 10, 20, () => {
      pdf.save("test.pdf");
    });
  }
 




}
