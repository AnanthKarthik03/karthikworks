-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 22, 2017 at 02:53 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `qid` int(11) NOT NULL,
  `college` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `year` int(10) NOT NULL,
  `mid` int(10) NOT NULL,
  `sem` int(10) NOT NULL,
  `sub` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`qid`, `college`, `dept`, `year`, `mid`, `sem`, `sub`, `date`) VALUES
(1, 'rec', 'COMPUTER SCIENCE AND ENGINEERING', 2, 1, 2, 'DATA COMMUNICATION', '2017-08-16');

-- --------------------------------------------------------

--
-- Table structure for table `list`
--

CREATE TABLE `list` (
  `qid` int(10) NOT NULL,
  `question` longtext NOT NULL,
  `subject` varchar(50) NOT NULL,
  `setno` int(10) NOT NULL,
  `level` varchar(10) NOT NULL,
  `checked` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `list`
--

INSERT INTO `list` (`qid`, `question`, `subject`, `setno`, `level`, `checked`) VALUES
(46, 'What is Geology? Explain in brief about different branches of Geology.', 'maths', 1, 'easy', 1),
(47, 'a.What are the requirements to be fulfilled by a substance to call it as a mineral?<br>\r\n b.What are the different methods of study of a mineral?', 'ENGINEERING GEOLOGY', 2, 'easy', 0),
(48, 'a. What is an Outcrop?<br>b.What are discussed in structural geology', 'ENGINEERING GEOLOGY', 3, 'hard', 0),
(49, 'what is a+b value', 'maths', 1, 'medium', 1),
(50, 'What is 123456? Explain in brief about different branches of Geology.', 'maths', 1, 'hard', 0),
(51, 'a.What is the importance of Geology in Civil Engineering?<br>b.What is weathering and explain the importance of weathering.', 'ENGINEERING GEOLOGY', 1, 'hard', 0),
(52, 'Briefly explain the case history of failures of some civil engineering structures due to geological drawbacks.', 'ENGINEERING GEOLOGY', 1, 'easy', 0),
(53, 'Explain different physical properties of a mineral and also give the properties of   KYANITE, HORNBLENDE, FELDSPAR.', 'ENGINEERING GEOLOGY', 2, 'easy', 0),
(54, 'Write the properties of GRANITE, PEGMATITE, DOLERITE, CONGLOMERATE, MARBLE.', 'ENGINEERING GEOLOGY', 2, 'hard', 0),
(55, 'Explain briefly about sedimentary and metamorphic rocks.', 'ENGINEERING GEOLOGY', 2, 'medium', 0),
(56, 'What is an Outcrop?\r\n', 'ENGINEERING GEOLOGY', 3, 'easy', 0),
(57, 'What is a Fold and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium', 0),
(58, 'What is a Fault and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium', 0),
(65, 'what is bbbb value??\r\n', 'maths', 1, 'easy', 0),
(66, 'what is aaa value?', 'maths', 1, 'medium', 0),
(67, 'what is ccc value??\r\n', 'maths', 1, 'hard', 0),
(85, 'What is Geology? Explain in brief about different branches of Geology.', 'ENGINEERING GEOLOGY', 1, 'easy', 0);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `qid` int(10) NOT NULL,
  `question` longtext NOT NULL,
  `subject` varchar(20) NOT NULL,
  `setno` int(5) NOT NULL,
  `level` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`qid`, `question`, `subject`, `setno`, `level`) VALUES
(1, 'What is Geology? Explain in brief about different branches of Geology.', 'ENGINEERING GEOLOGY', 1, 'easy'),
(2, 'a.What is the importance of Geology in Civil Engineering?<br>\r\n b.What is weathering and explain the importance of weathering.', 'ENGINEERING GEOLOGY', 1, 'medium'),
(3, 'Briefly explain the case history of failures of some civil engineering structures due to geological drawbacks.', 'ENGINEERING GEOLOGY', 1, 'hard'),
(4, 'Explain the factors responsible for weathering and also explain about the process of Geological agents.', 'ENGINEERING GEOLOGY', 1, 'easy'),
(5, 'Explain about the Geological work of a river.', 'ENGINEERING GEOLOGY', 1, 'hard'),
(6, 'a.What are the requirements to be fulfilled by a substance to call it as a mineral?\r\n <br>b.What are the different methods of study of a mineral?', 'ENGINEERING GEOLOGY', 2, 'medium'),
(7, 'Explain different physical properties of a mineral and also give the properties of   KYANITE, HORNBLENDE, FELDSPAR.', 'ENGINEERING GEOLOGY', 2, 'easy'),
(8, 'Write the properties of GRANITE, PEGMATITE, DOLERITE, CONGLOMERATE, MARBLE.', 'ENGINEERING GEOLOGY', 2, 'medium'),
(9, 'Explain briefly about sedimentary and metamorphic rocks.', 'ENGINEERING GEOLOGY', 2, 'hard'),
(10, 'Explain briefly about the types, structures, textures and forms of Igneous rocks.', 'ENGINEERING GEOLOGY', 2, 'hard'),
(11, 'a. What is an Outcrop?<br>b.What are discussed in structural geology', 'ENGINEERING GEOLOGY', 3, 'easy'),
(12, 'What is a Fold and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium'),
(13, 'What is a Fault and explain its parts and types with neat sketches?', 'ENGINEERING GEOLOGY', 3, 'medium'),
(14, 'Explain briefly about Joints and Unconformities.', 'ENGINEERING GEOLOGY', 3, 'easy'),
(15, 'Explain STRIKE, DIP, HADE, DIP AMOUNT, SLIP.', 'ENGINEERING GEOLOGY', 3, 'hard'),
(17, 'what is bbbb value??\r\n', 'maths', 1, 'easy'),
(18, 'what is bbbb value??\r\n', 'maths', 1, 'medium'),
(19, 'what is bbbb value??\r\n', 'maths', 1, 'hard');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`qid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `list`
--
ALTER TABLE `list`
  MODIFY `qid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `qid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
