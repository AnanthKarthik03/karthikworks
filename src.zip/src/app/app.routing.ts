import { Routes, RouterModule } from '@angular/router';

import { AppheaderComponent, AppfooterComponent, AppmenuComponent, AppsettingsComponent } from 
'./index';

import { AppregisterComponent } from './appregister/appregister.component';
import { ApploginComponent } from './applogin/applogin.component';
import { AppComponent } from "app/app.component";
import { NewComponent } from "app/new/new.component";
import { HtmlComponent } from './html/html.component';
import { CssComponent } from './css/css.component';
import { BootstrapComponent } from './bootstrap/bootstrap.component';
import { DeveloperComponent } from './developer/developer.component';
import { JsComponent } from './js/js.component';
import { AngularComponent } from './angular/angular.component';
import { PhpComponent } from './php/php.component';
import { NodejsComponent } from './nodejs/nodejs.component';





const appRoutes: Routes = [
   
    { path: 'register', component: AppregisterComponent },
    { path: 'new', component: NewComponent },
    { path: 'html', component:HtmlComponent},
    { path: 'css', component:CssComponent},
    { path: 'bootstrap', component:BootstrapComponent},
    { path: 'developer', component:DeveloperComponent},
    { path: 'js', component:JsComponent},
    { path: 'angular', component:AngularComponent},
    { path: 'php', component:PhpComponent},
    { path: 'nodejs', component:NodejsComponent},

    

    // otherwise redirect to home
     { path: '', component: ApploginComponent,pathMatch: 'full' },
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);