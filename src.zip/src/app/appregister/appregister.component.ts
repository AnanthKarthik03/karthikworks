import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RegisterService} from './appregister.service'

@Component({
  selector: 'app-appregister',
  templateUrl: './appregister.component.html',
  styleUrls: ['./appregister.component.css']
})
export class AppregisterComponent implements OnInit {
    model: any = {};
    det:any={};
    loading = false;
    details:any;

  constructor(private router: Router,private _register:RegisterService) { }

  ngOnInit() {
  }

    register() {
        this.loading = true;
        this._register.reg(this.model)
            .subscribe(
                data => {
                  
                }, );
               this.router.navigate(['/details']);
    }
    get(){
       // console.log()
        this.loading=true;
        this._register.getDet(this.det)
        .subscribe(
               details => this.details = details );
               console.log(this.details)
    }
}
