import { Component } from '@angular/core';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  
})
export class NewComponent {
  title = 'app works!';
}
