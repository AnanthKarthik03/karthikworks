import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { AppregisterComponent } from './appregister/appregister.component';
import { ApploginComponent } from './applogin/applogin.component';
import { AppheaderComponent, AppfooterComponent, AppmenuComponent, AppsettingsComponent } from 
  './index';
import { NewComponent } from "app/new/new.component";
import { HtmlComponent } from './html/html.component';
import { CssComponent } from './css/css.component';
import { BootstrapComponent } from './bootstrap/bootstrap.component';
import { DeveloperComponent } from './developer/developer.component';
import { JsComponent } from './js/js.component';
import { AngularComponent } from './angular/angular.component';
import { PhpComponent } from './php/php.component';
import { NodejsComponent } from './nodejs/nodejs.component';


@NgModule({
  declarations: [
    AppComponent,
    AppheaderComponent,
    AppfooterComponent,
    AppmenuComponent,
    AppsettingsComponent,
    AppregisterComponent,
    ApploginComponent,
    NewComponent,
    HtmlComponent,
    CssComponent,
    BootstrapComponent,
    DeveloperComponent,
    JsComponent,
    AngularComponent,
    PhpComponent,
    NodejsComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
