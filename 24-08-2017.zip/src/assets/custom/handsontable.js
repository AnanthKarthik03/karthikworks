$(document).ready(function() {

    var myData = [
        ["", "Kia", "Nissan", "Toyota", "Honda"],
        ["2008", 10, 11, 12, 13],
        ["2009", 20, 11, 14, 13],
        ["2010", 30, 15, 12, 13]
    ];

    $("#exampleGrid").handsontable({
        data: myData,
        startRows: 5,
        startCols: 5,
        //minSpareCols: 1, //always keep at least 1 spare row at the right
        //minSpareRows: 1, //always keep at least 1 spare row at the bottom,
        rowHeaders: true,
        colHeaders: true,
        contextMenu: true,
        currentRowClassName: 'currentRow',
        currentColClassName: 'currentCol',
        outsideClickDeselects: false

    });

    $edit = $('#exampleGrid');

    function editRows() {

        $('#addtop').on('click', function() {
            $edit.handsontable('alter', 'insert_row', 0);
        });

        $('#addbottom').on('click', function() {
            $edit.handsontable('alter', 'insert_row');
        });

        var selection = $edit.handsontable('getSelected');
        $('.deletebutton').on('click', function() {
            $edit.handsontable('alter', 'remove_row', selection[0], selection[2]);
        });


    }

    editRows();

});