import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { ExportService } from '../common/export.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
declare let jsPDF;
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  @ViewChild('test') el: ElementRef;

  selectedItems2(arg0: any): any {
    throw new Error("Method not implemented.");
  }
  dropdownSettings: { singleSelection: boolean; text: string; selectAllText: string; unSelectAllText: string; enableSearchFilter: boolean; classes: string; };
  selectedItems: { "id": number; "itemName": string; }[];
  dropdownList: { "id": number; "itemName": string; }[];
  alluers: any;
  allusers: any;
  data: Array<any>;
  msg: boolean;
  model: any;
  allUsers: any[];
  constructor(private service: ApiService, public router: Router, private _exportService: ExportService) { }
  quelist = [];
  quelist1 = [];
  quelist2 = [];
  quelistinfo = [];
  ngOnInit() {
    this.service.getmcqquestionslist().subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });

    this.service.getmcqquestionslist1().subscribe(ques => {
      console.log(ques);
      this.quelist1 = ques;
    });
    this.service.getmcqquestionslist2().subscribe(ques => {
      console.log(ques);
      this.quelist2 = ques;
    });
    this.service.getinfo().subscribe(ques => {
      console.log(ques);
      this.quelistinfo = ques;
    });
  }
  myForm = new FormGroup({
    course: new FormControl()
  });
  quesentry() {
    this.router.navigate(['quesentry']);
  }
  send(value) {
    console.log(value);
  }
  refresh() {
    location.reload();
  }
  public download() {
    var doc = new jsPDF();
    doc.text(20, 20, 'Hello world!');
    doc.save('Test.pdf');
  }
  public pdfHtml() {
    let pdf = new jsPDF();
    pdf.addHTML(this.el.nativeElement, 10, 20, () => {
      pdf.save("test.pdf");
    });
  }







}
