import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-quesentry',
  templateUrl: './quesentry.component.html',
  styleUrls: ['./quesentry.component.css']
})
export class QuesentryComponent implements OnInit {
  constructor(private service: ApiService, public router: Router) { }
  ngOnInit() {
  }
  myForm = new FormGroup({
    question: new FormControl(),
    subject: new FormControl(),
    setno: new FormControl(),
    level: new FormControl()
  });
  save(value) {
    console.log(value);
    this.service.savemcqquestions(value).subscribe(ques => {
    });
  }
  set(value) {
    console.log(value);
  }
  queslist() {
    this.router.navigate(['queslist']);
  }
  selstatus;
  statusChange($event) {
    this.selstatus = $event.srcElement.value;
  }
}