import { Component, OnInit,EventEmitter,Output,Input } from '@angular/core';
//import { DashboardComponent} from '../dashboard/dashboard.component';
import {ApiService} from '../api.service';
@Component({
  selector: 'app-leftnav',
  templateUrl: './leftnav.component.html',
  styleUrls: ['./leftnav.component.css']
})
export class LeftnavComponent implements OnInit {
@Output() selectedpage=new EventEmitter();
 role=localStorage.getItem('role');
  constructor( public api:ApiService ) { }

  ngOnInit() {
     console.log(this.role);
  }
sidebarchage(type:string){
//  this.api.livePage=
this.selectedpage.emit(type);
}


 
 
}
