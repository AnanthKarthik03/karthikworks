import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ApiService } from '../api.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-questionslist',
  templateUrl: './questionslist.component.html',
  styleUrls: ['./questionslist.component.css']
})
export class QuestionslistComponent implements OnInit {
  subject: any;
  msg: boolean;
  model: any;
  data: any[];
  allUsers: any[];
  constructor(private service: ApiService, public router: Router) { }
  quelist = [];
  ngOnInit() {
    this.service.getmcqquestions().subscribe(ques => {
      console.log(ques);
      this.quelist = ques;
    });
  }
  private _values1 = [
    { id: 1, val: "1" },
    { id: 2, val: "2" },
    { id: 3, val: "3" },
    { id: 4, val: "4" },
  ];
  private _values3 = [
    { id: 1, val: "1" },
    { id: 2, val: "2" },
  ];
  private _values2 = [];
  private _values4 = [];
  firstDropDownChanged(val: any) {
    const obj = this._values1[val];
    const obj2 = this._values3[val];
    console.log(val, obj, obj2);
    if (!obj) return;
    if (obj.id == 1) {
      this._values2 = ["1-1", "1-2"];
    }
    else if (obj.id == 2) {
      this._values2 = ["2-1", "2-2"];
    }
    else if (obj.id == 3) {
      this._values2 = ["3-1", "3-2"];
    }
    else if (obj.id == 4) {
      this._values2 = ["4-1", "4-2"];
    }
    if (obj.id == 1 && obj2.id == 1) {
      this._values4 = ["c", "maths-1", "chemistry", "physics", "workshpo"];
    }
    else if (obj.id == 1 && obj2.id == 2) {
      this._values4 = ["c++", "maths-2", "engg drawing", "DLD", "data structures"];
    }
    else if (obj.id == 2 && obj2.id == 1) {
      this._values4 = ["OOPS", "ADS", "EM", "Mathamaical Methods", "IT"];
    }
    else if (obj.id == 2 && obj2.id == 2) {
      this._values4 = ["java", "advance java", "ethics", "science", "python"];
    }
    else {
      this._values2 = [];
    }
  }
  myForm = new FormGroup
    ({
      year: new FormControl(),
      mid: new FormControl(),
      sem: new FormControl(),
      subject: new FormControl(),
    });
  quesentry() {
    this.router.navigate(['quesentry']);
  }
  save(value) {
    this.myForm.value.sub = this.subject;
    console.log(this.myForm.value.subject);

    this.service.getsub(this.myForm.value.subject).subscribe(subject => {
      this.subject = subject;
      console.log(this.subject);
    })
  }
  click(value) {
    console.log(value);
    this.service.select(value).subscribe(ques => {
    });
  }
  declick(value) {
    console.log(value);
    this.service.deselect(value).subscribe(ques => {
    });
  }
}