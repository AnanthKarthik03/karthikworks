import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule, Form, FormGroup, FormBuilder, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes, Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AppComponent } from './app.component';
import { ApiService } from './api.service'; 
import { ValuesPipe } from './values.pipe';
import { AuthGuard } from './authentication';
import { HeaderComponent } from './header/header.component';
import { LeftnavComponent } from './leftnav/leftnav.component';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { HotTableModule } from 'ng2-handsontable';
import { Ng2TableModule } from 'ng2-table/ng2-table';
import { SelectModule } from 'ng-select';
import { FooterComponent } from './footer/footer.component';
import { DataTableModule } from "angular2-datatable";
import { DataFilterPipe } from './datatable-filter';
import { ExportService } from './common/export.service';
import { CKEditorModule } from 'ng2-ckeditor';
import { Pipe, PipeTransform } from '@angular/core';
import { UniquePipe } from "../uniquepipe";
import { QuesentryComponent } from './quesentry/quesentry.component';
import { QuestionslistComponent } from './questionslist/questionslist.component';
import { DashboardComponent } from "./dashboard/dashboard.component";
import { ListComponent } from './list/list.component';
import { RpqComponent } from './rpq/rpq.component';
import { DatePickerModule } from 'ng2-datepicker';
import { HomeComponent } from './home/home.component';
const approutes: Routes =
  [
    { path: '', component: DashboardComponent },
    { path: 'dashboard', component: DashboardComponent },
    { path: 'dashboard/:livePage', component: DashboardComponent },
    { path: '', component: QuesentryComponent },
    { path: '', component: QuestionslistComponent },
    { path: 'quesentry', component: QuesentryComponent },
    { path: '', component: ListComponent },
    { path: 'quesentry', component: ListComponent },
    { path: 'rpq', component: RpqComponent },
    { path: 'queslist', component: QuestionslistComponent },
    { path:'home',component:HomeComponent},
  ]

@NgModule({
  declarations:
  [
    AppComponent,
    DashboardComponent,
    ValuesPipe,
    UniquePipe,
    HeaderComponent,
    LeftnavComponent,
    FooterComponent,
    DataFilterPipe,
    QuesentryComponent,
    QuestionslistComponent,
    ListComponent,
    RpqComponent,
    HomeComponent,
  ],

  imports:
  [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(approutes),
    ReactiveFormsModule,
    Ng2SmartTableModule,
    HotTableModule,
    Ng2TableModule,
    SelectModule,
    DataTableModule,
    CKEditorModule,
    DatePickerModule,

  ],

  providers: [
    ApiService,
    AuthGuard,
    ExportService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
