import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
@Injectable()
export class ApiService {
    headers = new Headers({ 'Content-Type': 'application/json', 'Accept': 'application/json' }); // ... Set content type to JSON
    options = new RequestOptions({ headers: this.headers });
    livePage: string;
    role: any;
    constructor(private http: Http) { }
    savemcqquestions(body) {
        console.log(body);

        return this.http.post('http://localhost/myworks/api/savemcqquestions', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())

    }
    saveinfo(body) {
        console.log(body);
        return this.http.post('http://localhost/myworks/api/saveinfo', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())
    }
    select(value) {
        console.log(value);
        return this.http.post('http://localhost/myworks/api/select', JSON.stringify(value), this.options)
            .map((res: Response) => res.json())
    }

    deselect(value) {
        console.log(value);
        return this.http.post('http://localhost/myworks/api/deselect', JSON.stringify(value), this.options)
            .map((res: Response) => res.json())
    }
    savemcqquestions1(body) {
        return this.http.post('http://localhost/myworks/api/savemcqquestions1', JSON.stringify(body), this.options)
            .map((res: Response) => res.json())
    }
    getmcqquestions() {

        return this.http.get('http://localhost/myworks/api/getmcqquestions', this.options).map((res: Response) => res.json())
    }
    getsub(value) {
        console.log(value);
        let bodyString = JSON.stringify(value);
        return this.http.post('http://127.0.0.1/myworks/api/getsub', bodyString, this.options).map((res: Response) => res.json());
    }
    getmcqquestionslist() {

        return this.http.get('http://localhost/myworks/api/getmcqquestionslist', this.options).map((res: Response) => res.json())
    }
    getmcqquestionslist1() {

        return this.http.get('http://localhost/myworks/api/getmcqquestionslist1', this.options).map((res: Response) => res.json())
    }
    getmcqquestionslist2() {

        return this.http.get('http://localhost/myworks/api/getmcqquestionslist2', this.options).map((res: Response) => res.json())
    }
    getinfo() {

        return this.http.get('http://localhost/myworks/api/getinfo', this.options).map((res: Response) => res.json())
    }
}

