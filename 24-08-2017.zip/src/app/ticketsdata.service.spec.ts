import { TestBed, inject } from '@angular/core/testing';

import { TicketsdataService } from './ticketsdata.service';

describe('TicketsdataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TicketsdataService]
    });
  });

  it('should ...', inject([TicketsdataService], (service: TicketsdataService) => {
    expect(service).toBeTruthy();
  }));
});
