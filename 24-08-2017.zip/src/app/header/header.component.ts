import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  noifications;
  constructor(private router: Router, public api: ApiService) { }

  ngOnInit() {
  }
  sidebarchage(type: string) {
    this.api.livePage = type;
  }
}
