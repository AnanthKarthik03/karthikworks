import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RpqComponent } from './rpq.component';

describe('RpqComponent', () => {
  let component: RpqComponent;
  let fixture: ComponentFixture<RpqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RpqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RpqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
