import { Component, OnInit } from '@angular/core';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { Router } from "@angular/router";
@Component({
  selector: 'app-rpq',
  templateUrl: './rpq.component.html',
  styleUrls: ['./rpq.component.css']
})
export class RpqComponent implements OnInit {
  options: DatePickerOptions;
  constructor(private service: ApiService, public router: Router) {
    this.options = new DatePickerOptions();
  }
  ngOnInit() {
  }
  myForm = new FormGroup({
    college: new FormControl(),
    dept: new FormControl(),
    year: new FormControl(),
    mid: new FormControl(),
    sem: new FormControl(),
    sub: new FormControl(),
    date: new FormControl(),
  });
  save(value) {
    console.log(value);
    this.service.saveinfo(value).subscribe(ques => {
    });
  }
}
